const Validator = require('Validator');
const common = require('../../../config/common');
const express    = require('express');        // call express
const template_data = require('../../../config/template');
const router = express.Router();// get an instance of the express Router
// Language file load
const localizify = require('localizify');
const { t } = require('localizify');

const chef_model = require('./chef_model');

/*=============================================================================================================================
    Unique Details Check
=============================================================================================================================*/

    router.post("/unique_details_check", function (req, res) {

        //request method encryption
        common.decryption(req, function (request) {
            localizify.setLocale(request.login_language);

            var rules = {
                email: 'required',
                mobile_number: 'required',
            }

            const messages = {
                'required': t('required')
            }

            var v = Validator.make(request, rules, messages, {
                'email': t('field_email'),
                'mobile_number': t('field_mobile_number')
            })

            if (v.fails()) {

                var Validator_errors = v.getErrors();

                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };

                common.encryption(response_data, function (responseData) {
                    res.status(200);
                    res.json(responseData);
                })
            } else {

                var unique_key = {
                    'email': request.email,
                    'mobile_number': request.mobile_number
                };

                chef_model.check_unique(unique_key, function (response, msg, code) {

                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data, function (response) {
                        res.status(200);
                        res.json(response);
                    })

                }); //check_unique
            } //else
        }); //end decryption
    });

/*=============================================================================================================================
    User Registration
=============================================================================================================================*/

    router.post("/signup",function(req,res){

        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);

            var rules = {
                name: 'required',
                email: 'required|email',
                password: 'required',
                code: 'required',
                mobile_number: 'required',
                language: 'required',
                device_type: 'required',
                device_token:'required',
                uuid:'required',
                os_version:'required',
                device_name:'required',
                model_name:'required',
                ip:'',
            }

            const messages = {
                'required': t('required'),
                'email': t('email')
            }

            var v = Validator.make(request, rules, messages, 
                { 'name': t('field_name'),
                'email': t('field_email') ,
                'password': t('field_password') ,
                'code': t('field_country_code') ,
                'mobile_number': t('field_mobile_number') ,
                'language': t('field_language'),
                'device_type': t('field_device_type') ,
                'device_token': t('field_device_token') ,
                'uuid': t('field_uuid') ,
                'os_version': t('field_os_version') ,
                'device_name': t('field_device_name') ,
                'model_name': t('field_model_name') ,
                'ip': t('field_ip')})
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
                
                //process.exit();
                
                var unique_key = {'email':request.email,'mobile_number':request.mobile_number};
                chef_model.check_unique(unique_key,function(response, msg, code){
                    
                    if (response == false) {

                        response_data = {
                            code: 0,
                            message: msg
                        };
                        common.encryption(response_data,function(response){
                            res.status(200);
                            res.json(response);
                        })
                        
                    }
                    else {
                        
                        chef_model.signup(request,function(response, msg, code){
                    
                            response_data = {
                                code: code,
                                message: msg
                            };

                            if (code == 1) {
                                response_data.data = response;
                            }

                            common.encryption(response_data,function(responseData){
                                res.status(200);
                                res.json(responseData);
                            })
                        });//signup
                    }//end else

            });//check_unique
                
            }//else
        });//end decryption
    });


/*=============================================================================================================================
            Login
=============================================================================================================================*/

    router.post("/login",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                email: 'required|email',
                password: 'required',
                language: 'required',
                device_type: 'required',
                device_token:'required',
                uuid:'required',
                os_version:'required',
                device_name:'required',
                model_name:'required',
                ip:'',
            }

            const messages = {
                'required': t('required'),
                'email': t('email')
            }

            var v = Validator.make(request, rules, messages, 
                { 'email': t('field_email'),
                    'password': t('field_password') ,
                    'language': t('field_language'),
                    'device_type': t('field_device_type') ,
                    'device_token': t('field_device_token') ,
                    'uuid': t('field_uuid') ,
                    'os_version': t('field_os_version') ,
                    'device_name': t('field_device_name') ,
                    'model_name': t('field_model_name') ,
                    'ip': t('field_ip')
            })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                chef_model.login_details(request,function(response, msg, code){
                    //console.log(response)

                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })

                });//end login_details
                
            }//end else
        });//end function decryption
    });


/*=============================================================================================================================
            Send OTP
=============================================================================================================================*/

    router.post("/send_otp",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                code: 'required',
                mobile_number: 'required',
            }

            const messages = {
                'required': t('required')
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'code': t('field_code') ,
                    'mobile_number': t('field_mobile_number') ,
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
                
                chef_model.send_otp(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//send_otp
                    
            }//else
        });//end decryption
    });


/*=============================================================================================================================
            Verify OTP
=============================================================================================================================*/

    router.post("/verify_otp",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                code: 'required',
                mobile_number: 'required',
                otp: 'required',
            }

            const messages = {
                'required': t('required')
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'code': t('field_code') ,
                    'mobile_number': t('field_mobile_number') ,
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: '0',
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
                
                chef_model.verify_otp(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//verify_otp
                    
            }//else
        });//end decryption
    });


/*=============================================================================================================================
            Chef Details
=============================================================================================================================*/

    router.get("/chef_details",function(req,res){
        
        localizify.setLocale(req.login_language);
        chef_model.chef_details(req.login_user_id,function(response, msg, code){
            response_data = {
                code: code,
                message: msg,
            };

            if (code == 1) {
                response_data.data = response;
            }

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        }); // chef_details
    });


/*=============================================================================================================================
            Edit profile
=============================================================================================================================*/

    router.post("/edit_profile",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                name: 'required',
                email: 'required',
                address: 'required',
                latitude:'',
                longitude:'',
            }

            const messages = {
                'required': t('required'),
                'email': t('email')
            }

            var v = Validator.make(request, rules, messages,
                { 'name': t('field_name'),
                    'address': t('field_address') ,
                    'email': t('field_email') ,
                    'latitude': t('field_latitude') ,
                    'longitude': t('field_longitude'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
                
                chef_model.edit_profile(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//edit_profile
                    
            }//else
        });//end decryption
    });


/*=============================================================================================================================
            Change user password
=============================================================================================================================*/

    router.post("/change_password",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                old_password: 'required',
                new_password: 'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 'old_password': t('field_old_password'),
                    'new_password': t('field_new_password')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.change_password(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code != 0) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//change_password
            }//else
        });//end decryption
    });


/*=============================================================================================================================
            Change user language
=============================================================================================================================*/

    router.post("/change_language",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                language: 'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 'language': t('field_language'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.change_language(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code != 0) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//change_language
            }//else
        });//end decryption
    });

/*=============================================================================================================================
            Update Device Info
=============================================================================================================================*/

    router.post("/update_device_info",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                device_type: 'required',
                device_token:'required',
                uuid:'required',
                os_version:'required',
                device_name:'required',
                model_name:'required',
                ip:'',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'device_type': t('field_device_type') ,
                    'device_token': t('field_device_token') ,
                    'uuid': t('field_uuid') ,
                    'os_version': t('field_os_version') ,
                    'device_name': t('field_device_name') ,
                    'model_name': t('field_model_name') ,
                    'ip': t('field_ip')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.change_device_info(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//change_device_info
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Add Or Update Other Info
=============================================================================================================================*/

    router.post("/add_update_other_info",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                about_me: 'required',
                address: 'required',
                latitude:'required',
                longitude:'required',
                documents:'',
                certificate:''
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'about_me': t('field_about_me') ,
                    'address': t('field_address') ,
                    'latitude': t('field_latitude') ,
                    'longitude': t('field_longitude') , 
                    'documents': t('field_documents') , 
                    'certificate': t('field_certificate') , 
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.add_update_other_info(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//add_update_other_info
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Update Document
=============================================================================================================================*/

    router.post("/update_document",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                document_id: '',
                document:'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'document_id': t('field_document_id') ,
                    'document': t('field_documents') , 
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.update_document(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//update_document
            }//else
        });//end decryption
    });

/*=============================================================================================================================
        Delete Document
=============================================================================================================================*/

    router.post("/delete_document",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                document_id: 'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'document_id': t('field_document_id') ,
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.delete_document(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//delete_document
            }//else
        });//end decryption
    });

/*=============================================================================================================================
        Update Certificate
=============================================================================================================================*/

    router.post("/update_certificate",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                certificate_id: '',
                certificate:'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'certificate_id': t('field_certificate_id') ,
                    'certificate': t('field_certificate') , 
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.update_certificate(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//update_certificate
            }//else
        });//end decryption
    });

/*=============================================================================================================================
            Get Working Hours
=============================================================================================================================*/

    router.get("/get_bank_details",function(req,res){
        
        localizify.setLocale(req.login_language);
        chef_model.get_bank_details(req,function(response, msg, code){
            response_data = {
                code: code,
                message: msg,
            };

            if (code == 1) {
                response_data.data = response;
            }

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        }); // chef_details
    });

/*=============================================================================================================================
        Add Or Update Bank Details
=============================================================================================================================*/

    router.post("/add_update_bank_details",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                bank_name: 'required',
                bank_document: '',
                account_holder_name: 'required',
                account_number:'required',
                routing_number:'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'bank_name': t('field_bank_name') ,
                    'bank_document': t('field_bank_document') ,
                    'account_holder_name': t('field_account_holder_name') ,
                    'account_number': t('field_account_number') ,
                    'routing_number': t('field_routing_number') , 
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.add_update_bank_details(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//add_update_bank_details
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Add Or Update Working Hours
=============================================================================================================================*/

    router.post("/add_update_working_hours",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                working_hours: 'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'working_hours': t('field_working_hours')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.add_update_working_hours(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//add_update_working_hours
            }//else
        });//end decryption
    });



/*=============================================================================================================================
            Get Working Hours
=============================================================================================================================*/

    router.get("/get_working_hours",function(req,res){
        
        localizify.setLocale(req.login_language);
        chef_model.get_working_hours(req,function(response, msg, code){
            response_data = {
                code: code,
                message: msg,
            };

            if (code == 1) {
                response_data.data = response;
            }

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        }); // chef_details
    });

/*=============================================================================================================================
        Add Or Update Food Speciality
=============================================================================================================================*/

    router.post("/add_update_food_speciality",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                food_type_id: 'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'food_type_id': t('field_food_type_id')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.add_update_food_speciality(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//add_update_food_speciality
            }//else
        });//end decryption
    });

/*=============================================================================================================================
            Forgot Password
=============================================================================================================================*/

    router.post("/forgot_password",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            
            var rules = {
                email: 'required|email',
            }

            const messages = {
                'required': t('required'),
                'email': t('email')
            }

            var v = Validator.make(request, rules, messages,
                { 'email': t('field_email')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.forgot_password(request,function(response, msg, code){
            
                    if(code == 0){

                        response_data = {
                            code: code,
                            message: msg,
                        };

                        common.encryption(response_data,function(response){
                            res.status(200);
                            res.json(response);
                        })
                        
                    }
                    else {
                        template_data.forgot_password(response,function(result){

                            //console.log(response);
                            var subject = 'Application Forgot Password';
                            common.send_email(subject,request.email,result,function(result){
                                response_data = {
                                    code: code,
                                    message: msg
                                };

                                common.encryption(response_data,function(response){
                                    res.status(200);
                                    res.json(response);
                                })
                            })  // Send Email
                        }); // template making
                    }//end else
                });//forgot_password
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Contact Us
=============================================================================================================================*/

    router.post("/contact_us",function(req,res){

        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                subject: 'required',
                description: 'required'
            }

            const messages = {
                'required': t('required')
            }

            var v = Validator.make(request, rules, messages,{'subject': t('field_subject'), 'description': t('field_description')})
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                chef_model.contact_us(request,function(response, msg, code){

                    chef_model.chef_details(request.login_user_id,function(user){

                        request.name = user['name'];
                        request.email = user['email'];
                        request.mobile_number = user['mobile_number'];

                        template_data.contact_us_link(request,function(result){

                            // console.log(result);
                            var subject = t('text_contact_email_subject',{app:process.env.APP_NAME});
                            common.send_email(subject,process.env.FROM_EMAIL,result,function(result){
                                response_data = {
                                    code: code,
                                    message: msg,
                                };

                                common.encryption(response_data,function(response){
                                    res.status(200);
                                    res.json(response);
                                })
                            })  // Send Email
                            
                        }); // template making 
                    })
                    

                });//end contact_us
                
            }//end else
        });//end function decryption
    });


/*=============================================================================================================================
            Logout
=============================================================================================================================*/

    router.get("/logout",function(req,res){
        
        localizify.setLocale(req.login_language);
        chef_model.logout(req,function(response, msg, code){

            response_data = {
                code: code,
                message: msg,
            };

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        })//end logout User
    });

/*=============================================================================================================================
            Deactivate Account
=============================================================================================================================*/

    router.get("/deactivate_account",function(req,res){
        
        localizify.setLocale(req.login_language);
        chef_model.deactivate_account(req,function(response, msg, code){

            response_data = {
                code: code,
                message: msg,
            };

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        })//end deactivate_account
    });


/*=============================================================================================================================
            Food Type List
=============================================================================================================================*/

    router.get("/food_type_list",function(req,res){
        
        localizify.setLocale(req.login_language);
        chef_model.food_type_list(function(response, msg, code){
            response_data = {
                code: code,
                message: msg,
            };

            if (code == 1) {
                response_data.data = response;
            }

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        });
    });


/*=============================================================================================================================
        Get Settings
=============================================================================================================================*/
    
    router.get("/get_setting",function(req,res){
        
        localizify.setLocale(req.login_language);
        chef_model.get_setting(function(response, msg, code){
            response_data = {
                code: code,
                message: msg,
            };

            if (code == 1) {
                response_data.data = response;
            }

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        });
    });

/*=============================================================================================================================
        Add Menu Category
=============================================================================================================================*/

    router.post("/add_menu_category",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                category: 'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'category': t('field_category')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.add_menu_category(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//add_menu_category
            }//else
        });//end decryption
    });



/*=============================================================================================================================
        Delete Menu Category
=============================================================================================================================*/

    router.post("/delete_menu_category",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                id: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'dish_id': t('field_dish_id'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.delete_menu_category(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//delete_menu_category
            }//else
        });//end decryption
    });



/*=============================================================================================================================
            Menu Category List
=============================================================================================================================*/

    router.get("/menu_category_list",function(req,res){
        
        localizify.setLocale(req.login_language);
        chef_model.menu_category_list(req, function(response, msg, code){
            response_data = {
                code: code,
                message: msg,
            };

            if (code == 1) {
                response_data.data = response;
            }

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        });
    });


/*=============================================================================================================================
        Add Menu
=============================================================================================================================*/

    router.post("/add_menu",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                menu_category_id: 'required',
                dish_name: 'required',
                dish_price: 'required',
                dish_image: 'required',
                description: 'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'menu_category_id': t('field_category'),
                    'dish_name': t('field_dish_name'),
                    'dish_price': t('field_dish_price'),
                    'dish_image': t('field_image'),
                    'description': t('field_description'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.add_menu(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//add_menu
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Edit Menu
=============================================================================================================================*/

    router.post("/edit_menu",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                dish_id: 'required|numeric',
                menu_category_id: 'required',
                dish_name: 'required',
                dish_price: 'required',
                dish_image: 'required',
                description: 'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'dish_id': t('field_dish_id'),
                    'menu_category_id': t('field_category'),
                    'dish_name': t('field_dish_name'),
                    'dish_price': t('field_dish_price'),
                    'dish_image': t('field_image'),
                    'description': t('field_description'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.edit_menu(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//edit_menu
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Delete Menu
=============================================================================================================================*/

    router.post("/delete_menu",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                dish_id: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'dish_id': t('field_dish_id'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.delete_menu(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//delete_menu
            }//else
        });//end decryption
    });



/*=============================================================================================================================
        Make Available
=============================================================================================================================*/

    router.post("/make_available",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                is_chef_available: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'is_chef_available': t('field_is_chef_available'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.make_available(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//make_available
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Menu List
=============================================================================================================================*/

    router.post("/menu_list",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                menu_category_id: 'required',
                page: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'menu_category_id': t('field_category'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                if (request.page == '0' || request.page == undefined) {
                    request.page = 1
                }

                request.per_page = process.env.PER_PAGE;

                request.limit = ((request.page - 1) * request.per_page)
        
                chef_model.menu_list(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//menu_list
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Order List
=============================================================================================================================*/

    router.post("/order_list",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                status: 'required|in:Request,Preparing,Ready,Completed,Cancelled',
                page: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'status': t('field_status'),
                    'page': t('field_page'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                if (request.page == '0' || request.page == undefined) {
                    request.page = 1
                }

                request.per_page = process.env.PER_PAGE;

                request.limit = ((request.page - 1) * request.per_page)
        
                chef_model.order_list(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//order_list
            }//else
        });//end decryption
    });

/*=============================================================================================================================
        Order Details
=============================================================================================================================*/

    router.post("/order_details",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                order_id: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'order_id': t('field_order_id')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.order_details(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }
                    
                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//order_details
            }//else
        });//end decryption
    });

/*=============================================================================================================================
            Approve or Reject Order
=============================================================================================================================*/

    router.post("/approve_reject_order",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                order_id: 'required|numeric',
                status: 'required|in:Approved,Rejected',
                cancel_reason: '',
            }

            const messages = {
                'required': t('required'),
                'numeric' : t('numeric')
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'order_id': t('field_order_id'),
                    'status': t('field_status')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                chef_model.approve_reject_order(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })

                })//end approve_reject_order
                
            }//end else
        });//end function decryption
    });


/*=============================================================================================================================
            Change Status
=============================================================================================================================*/

    router.post("/change_status",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                order_id: 'required|numeric',
                status: 'required|in:Ready,Completed',
            }

            const messages = {
                'required': t('required'),
                'numeric' : t('numeric')
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'order_id': t('field_order_id'),
                    'status': t('field_status')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                chef_model.change_status(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })

                })//end change_status
                
            }//end else
        });//end function decryption
    });


/*=============================================================================================================================
        My Earning List
=============================================================================================================================*/

    router.post("/my_earning_list",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                page: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'status': t('field_status'),
                    'page': t('field_page'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                if (request.page == '0' || request.page == undefined) {
                    request.page = 1
                }

                request.per_page = process.env.PER_PAGE;

                request.limit = ((request.page - 1) * request.per_page)
        
                chef_model.my_earning_list(request,function(response, msg, code){

                    chef_model.earning_count(request,function(response1, msg1, code1){
            
                        response_data = {
                            code: code,
                            message: msg,
                        };

                        if (code == 1) {
                            response_data.data = {total: response1, list: response};
                        }

                        common.encryption(response_data,function(response){
                            res.status(200);
                            res.json(response);
                        })
                    });
                });//my_earning_list
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Chef rate Review List
=============================================================================================================================*/

    router.post("/chef_rate_review_list",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                page: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'page': t('field_page'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                request.per_page = process.env.PER_PAGE;

                request.limit = ((request.page - 1) * request.per_page)
        
                chef_model.chef_rate_review_list(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//chef_rate_review_list
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Review Alert
=============================================================================================================================*/

    router.get("/review_alert",function(req,res){
        
        localizify.setLocale(req.login_language);
        chef_model.review_alert(req, function(response, msg, code){
            response_data = {
                code: code,
                message: msg,
            };

            if (code == 1) {
                response_data.data = response;
            }

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        });
    });


/*=============================================================================================================================
        Give Review
=============================================================================================================================*/

    router.post("/give_review",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                order_id:'required|numeric',
                user_id: 'required|numeric',
                rating: 'required|numeric',
                review: '',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'order_id': t('field_order_id')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                chef_model.give_review(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };
                    
                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//give_review
            }//else
        });//end decryption
    });


module.exports = router;
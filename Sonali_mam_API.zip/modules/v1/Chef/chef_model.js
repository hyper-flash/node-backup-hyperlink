const con = require('../../../config/database');
const stripe = require('../../../config/stripe');
const common = require('../../../config/common');
const asyncLoop = require('node-async-loop');
const _randomhash = require('crypto-toolkit').RandomHash('base64-urlsafe');
const cryptoLib = require('cryptlib');
const shaKey = cryptoLib.getHashSha256(process.env.ENC_KEY, 32);
const moment = require('moment');
// Language file load
const { t } = require('localizify');

// get an instance of the express Router
var Chef = {

/*=============================================================================================================================
    User Registration
=============================================================================================================================*/

    signup: function(req,callback){

        var cimage = 'default-user.png';

        if (req.image != undefined && req.image != '') {
            var cimage = req.image;
        }

        var loginParams = {
            name: req.name,
            email: req.email,
            code: req.code,
            mobile_number: req.mobile_number,
            password: (req.password != undefined && req.password != '') ? cryptoLib.encrypt(req.password, shaKey, process.env.ENC_IV) : '',
            language: req.language,
            image: cimage,
            login_type: 'S',
            is_online: '1',
            last_login: moment().format('YYYY-MM-DD HH:mm'),
            role: 'Chef',
            chef_profile_status: 1,
            is_verify: '1',
            is_chef_available: '1'
        };

        /* Insert Login Details */
        con.query('INSERT INTO tbl_user SET ?', loginParams, function (err, result, _fields) {
            if (!err) {
                if (result.affectedRows) {

                    Chef.update_device_info(req,result.insertId,function(token){

                        Chef.chef_details(result.insertId,function(response,err){
                            response.token = token;

                            callback(response,t('text_customer_signup_success'),1);

                        }); // chef_details

                    }); // update_device_info

                } // if(result.affectedRows)
                else {
                    callback(null, t('text_customer_signup_fail'), 0);
                } // else
            } else {
                callback(null, t('text_customer_signup_fail'), 0);
            }

        });
    },


/*=============================================================================================================================
        Check Unique
=============================================================================================================================*/

    check_unique: function (unique_key, callback) {

        var len = Object.keys(unique_key).length;
        var i = 1;

        asyncLoop(unique_key, function (item, next) {
            //console.log(item);
            // Get object key with: item.key 
            // Get associated value with: item.value
            if (item.value != '' && item.value != undefined) {
                var query = con.query("SELECT * FROM tbl_user WHERE role = 'Chef' AND " + item.key + " = ? ", item.value, function (err, result, _fields) {

                    if (!err) {
                        if (result[0] == undefined) {
                            if (len == i) {
                                callback(true, t('text_rest_unique_succ'), 1);
                                return;
                            }
                        } else {
                            //console.log(item.key);
                            callback(false, t('text_rest_already_taken', {
                                field: item.key.replace("_", " ")
                            }), 0);
                            return;
                        }
                    } else {
                        callback(false, t('text_rest_already_taken', {
                            field: item.key.replace("_", " ")
                        }), 0);
                        return;

                    }
                    i++;
                    next();
                });
            } else {
                i++;
                next();
            }

        }, function () {
            callback();
        });
    },



/*=============================================================================================================================
        Update Device Info
=============================================================================================================================*/

    update_device_info: function(req,user_id,callback){
        //console.log(req);
        var query = con.query("DELETE FROM tbl_user_device WHERE user_id = '"+user_id+"' ", function (err, result, fields) {
            var token = _randomhash.sha256();
            var params  = {
                    user_id: user_id,
                    token : token,
                    device_type: req.device_type,
                    device_token: req.device_token,
                    uuid: req.uuid,
                    os_version: req.os_version,
                    device_name: req.device_name,
                    model_name: req.model_name,
                    ip: req.ip
                };
            var query = con.query('INSERT tbl_user_device SET ? ', params, function (err, result, fields) {
                callback(token);
            });
        });
         
    },


/*=============================================================================================================================
        Update Device Info
=============================================================================================================================*/

    change_device_info: function(req,callback){
        
        var params  = {
                device_type: req.device_type,
                device_token: req.device_token,
                uuid: req.uuid,
                os_version: req.os_version,
                device_name: req.device_name,
                model_name: req.model_name,
                ip: req.ip
            };
        var query = con.query('UPDATE tbl_user_device SET ? WHERE user_id = "'+req.login_user_id+'" ', params, function (err, result, fields) {
            callback(req, t('text_change_device_info'), 1);
        });
         
    },

/*=============================================================================================================================
        Add Or Update Other Info
=============================================================================================================================*/

    add_update_other_info: function(req,callback){

        var request = require("request");

        let options = { 
            method: 'GET',
            url: 'https://maps.googleapis.com/maps/api/geocode/json?latlng='+req.latitude+','+req.longitude+'&key=AIzaSyCI5fTiD_xW8mLDral3xeLhtJVyCfOMXFM',
            json: true 
        };

        request(options, (error, response, body) => {

        
            if (!error && body.results != undefined) {

                var google_address = body.results[0].address_components;

                var country_data = google_address.find(o => o.types[0] === 'country');

                Chef.countryDetails(country_data['short_name'], function(countrydetails) {
                                    
                    if (countrydetails != null) {

        
                        var params  = {
                            about_me: req.about_me,
                            address : req.address,
                            latitude: req.latitude,
                            longitude: req.longitude,
                            country: country_data['long_name']
                        };

                        var query = con.query("UPDATE tbl_user SET ? WHERE id = '"+req.login_user_id+"' ", params, function (err, result, fields) {

                            if(req.documents != undefined && req.documents != ''){
                                var doc_array = req.documents.split(",");
                                var params  = [];

                                for (var key in doc_array) {
                                    params.push([req.login_user_id,doc_array[key]]);
                                }

                                //console.log(params);
                                
                                var sql = "INSERT INTO tbl_chef_document (user_id,document) VALUES ?";
                                var query = con.query(sql, [params], function (err, result, fields) {
                                    //console.log(query.sql);

                                    if(req.certificate != undefined && req.certificate != ''){
                                        var certificate_array = req.certificate.split(",");
                                        var params  = [];

                                        for (var key in certificate_array) {
                                            params.push([req.login_user_id,certificate_array[key]]);
                                        }

                                        //console.log(params);
                                        
                                        var sql1 = "INSERT INTO tbl_chef_certificate (user_id,certificate) VALUES ?";
                                        var query = con.query(sql1, [params], function (err, result, fields) {
                                            //console.log(query.sql);
                                            
                                            Chef.chef_details(req.login_user_id,function(response,err){
                                                callback(response, t('text_chef_add_update_other_info_succ'),1);
                                            })

                                        });
                                    }else{
                                        Chef.chef_details(req.login_user_id,function(response,err){
                                            callback(response, t('text_chef_add_update_other_info_succ'),1);
                                        })
                                    }
                                    
                                    

                                });
                            }
                            else{
                                callback(null, t('text_chef_add_update_other_info_succ'),1);                
                            }
                        });
                    }
                    else{
                        callback(false, t('text_chef_invalid_country'),0);
                    }
                })

            }
            else{
                callback(null, t('api_valid_details'),0);                
            }
        })
            
    },


/*=============================================================================================================================
        Add Or Update Bank Details
=============================================================================================================================*/

    add_update_bank_details: function(req,callback){
       
        con.query("SELECT u.* FROM tbl_user u WHERE u.id = '"+req.login_user_id+"' ", function (err, chef_result, fields) {
            //console.log(result)
            if (!err && chef_result[0] != undefined) {

                chef_result = chef_result[0];
                con.query("SELECT * FROM tbl_bank_detail WHERE user_id = '"+req.login_user_id+"' ", function (err, bankResult, fields) {

                    var request = require("request");

                    let options = { 
                        method: 'GET',
                        url: 'https://maps.googleapis.com/maps/api/geocode/json?latlng='+chef_result.latitude+','+chef_result.longitude+'&key=AIzaSyCI5fTiD_xW8mLDral3xeLhtJVyCfOMXFM',
                        json: true 
                    };

                    request(options, (error, response, body) => {

                    
                        if (!error && body.results != undefined) {

                            var google_address = body.results[0].address_components;

                            var state = google_address.find(o => o.types[0] === 'administrative_area_level_1');
                            var country = google_address.find(o => o.types[0] === 'country');
                            var city = google_address.find(o => o.types[0] === 'locality');
                            var postal_code = google_address.find(o => o.types[0] === 'postal_code');

                            if(city == undefined){
                                city = google_address.find(o => o.types[0] === 'administrative_area_level_2');
                            }

                            if (country['short_name'] === 'US' && req.ssn_last == undefined) {

                                callback(false, t('text_chef_get_ssn_fail'),0);

                            } // if (country['short_name'] === 'US' && req.ssn_last == undefined) {
                            else{

                                if (!err && bankResult[0] != undefined && bankResult[0].merchant_account_id != '') {
                                    req.bank_document = bankResult[0].bank_document;
                                }
                                else{
                                    if(req.bank_document == undefined){
                                        req.bank_document  = '';
                                    }
                                }

                                Chef.countryDetails(country['short_name'], function(countrydetails) {
                                    
                                    if (countrydetails != null) {

                                        // var dateOfBirth  = request.dob.split("-");
                                        var birthYear = "1995";
                                        var birthMonth = "01";
                                        var birthDate = "01";
                                        stripe.uploadIdentityStripe({bank_document:req.bank_document}, function(fileObject, uploadmessage, uploadcode) {
                                            if (fileObject != null) {

                                                var external_account = {
                                                    object: 'bank_account',
                                                    country: country['short_name'],
                                                    currency: countrydetails.currency,
                                                    bank_name: req.bank_name,
                                                    account_holder_name: req.account_holder_name,
                                                    account_number: req.account_number,
                                                    routing_number: req.routing_number,
                                                }

                                                var accountObject = {
                                                    email: chef_result.email,
                                                    business_type: 'individual',
                                                    requested_capabilities: ['card_payments', 'transfers'],
                                                    business_profile: {
                                                        mcc: '5814', // Fast Food Restaurants
                                                        name: chef_result.name,
                                                        product_description: "Food Delivery Service",
                                                    },
                                                    individual: {
                                                        address: {
                                                            line1: chef_result.address,
                                                            state: state['short_name'],
                                                            city: city['long_name'],
                                                            postal_code: postal_code['short_name'],
                                                        },
                                                        dob: {
                                                            day: birthDate,
                                                            month: birthMonth,
                                                            year: birthYear,
                                                        },

                                                        email: chef_result.email,
                                                        first_name: chef_result.name,
                                                        last_name: "Where4",
                                                        phone: chef_result.code+chef_result.mobile_number,
                                                    },
                                                    tos_acceptance: {
                                                        date: Math.floor(Date.now() / 1000),
                                                        ip: (req.ip != undefined && req.ip != '')?req.ip:'192.168.1.173',
                                                    },
                                                    external_account: external_account,
                                                };
                                                
                                                        
                                                /* Already Added Bank Details Update Details  */
                                                if (!err && bankResult[0] != undefined && bankResult[0].merchant_account_id != '') {

                                                    stripe.updateAccount(bankResult[0].merchant_account_id, accountObject, function(account, bankmessage, bankcode) {

                                                        // console.log(account);
                                            
                                                        if (account != null) {
                                                            
                                                            var bankparams = {
                                                                user_id: req.login_user_id,
                                                                bank_name: req.bank_name,
                                                                account_holder_name: req.account_holder_name,
                                                                account_number: req.account_number,
                                                                routing_number: req.routing_number,
                                                                merchant_account_id: account.id,
                                                                bank_document: req.bank_document,
                                                                ssn_last: (country['short_name'] === 'US') ? req.ssn_last : "",
                                                                zipcode: postal_code['short_name'],
                                                                currency: countrydetails.currency
                                                            }

                                                            var query = con.query("UPDATE tbl_bank_detail SET ? WHERE user_id = '"+req.login_user_id+"' ", bankparams, function (err, result, fields) {

                                                                callback(true, t('text_chef_add_update_bank_details_succ'),1);
                                                                
                                                            });
                                                        }
                                                        else{
                                                            callback(false, bankmessage,0);
                                                        }
                                                    })
                                                }
                                                /* Add Bank Details */
                                                else{

                                                    accountObject.type = 'custom';
                                                    accountObject.country = country['short_name'];
                                                    accountObject.individual.verification = {
                                                            document: {
                                                                front: fileObject.id
                                                            },
                                                            additional_document: {
                                                                front: fileObject.id
                                                            }
                                                        };

                                                    if (country['short_name'] === 'US') {
                                                        accountObject.individual.ssn_last_4 = req.ssn_last;
                                                    }

                                                    stripe.createAccount(accountObject, function(account, bankmessage, bankcode) {
                                            
                                                        if (account != null) {
                                                            
                                                            var bankparams = {
                                                                user_id: req.login_user_id,
                                                                bank_name: req.bank_name,
                                                                account_holder_name: req.account_holder_name,
                                                                account_number: req.account_number,
                                                                routing_number: req.routing_number,
                                                                merchant_account_id: account.id,
                                                                bank_document: req.bank_document,
                                                                ssn_last: (country['short_name'] === 'US') ? req.ssn_last : "",
                                                                zipcode: postal_code['short_name'],
                                                                currency: countrydetails.currency
                                                            }

                                                            var query = con.query('INSERT tbl_bank_detail SET ? ', bankparams, function (err, result, fields) {

                                                                callback(true, t('text_chef_add_update_bank_details_succ'),1);
                                                            })
                                                        }
                                                        else{
                                                            callback(false, bankmessage,0);
                                                        }
                                                    })
                                                    
                                                }
                                                    
                                            } else {
                                                callback(false, uploadmessage,0);
                                            }
                                        });
                                    } // if (countrydetails != null) {
                                    else{
                                        callback(false, t('text_chef_invalid_country'),0);
                                    }
                                })
                            }
                            
                        } // if (!error && body.results != undefined) {
                        else{
                            // console.log(r.data);
                            callback(false, error,0);
                        }
                    })

                    
                })
            }
            else{
                callback(false, t('text_chef_get_bank_details_fail'),0);
            }
        })   
    },

    countryDetails: function(short_code, callback) {
        con.query("SELECT * FROM tbl_country WHERE short_code ='" + short_code + "' ", function(error, result, fields) {
            if (!error && result[0] != undefined) {
                callback(result[0]);
            } else {
                callback(null);
            }
        });
    },


/*=============================================================================================================================
        Get Working Hours
=============================================================================================================================*/

    get_bank_details: function(req,callback){
       

        var query = con.query("SELECT * FROM tbl_bank_detail WHERE user_id = '"+req.login_user_id+"' ", function (err, result, fields) {

            if (!err && result[0] != undefined) {

                callback(result, t('text_chef_get_bank_details_succ'),1);
            }
            else{
                callback(true, t('text_chef_get_bank_details_fail'),1);
            }
        })   
    },


/*=============================================================================================================================
        Add Or Update Working Hours
=============================================================================================================================*/

    add_update_working_hours: function(req,callback){

        con.query("DELETE FROM tbl_chef_working_hours WHERE user_id = '"+req.login_user_id+"' ", function (err, result, fields) {

            var params  = [];

            try {
                var data = JSON.parse(req.working_hours);
            } catch (e) {
                var data = req.working_hours;
            }

            for (var key in data) {
                params.push([req.login_user_id,data[key]['days'], data[key]['start_time'], data[key]['end_time'], data[key]['available']]);
            }

            
            var sql = "INSERT INTO tbl_chef_working_hours (`user_id`, `days`, `start_time`, `end_time`, `available`) VALUES ?";
            var query = con.query(sql, [params], function (err, result, fields) {
                // console.log(err);
                callback(true, t('text_chef_add_update_working_hours_succ'),1);

            });
        });
          
    },


/*=============================================================================================================================
        Get Working Hours
=============================================================================================================================*/

    get_working_hours: function(req,callback){
       

        var query = con.query("SELECT * FROM tbl_chef_working_hours WHERE user_id = '"+req.login_user_id+"' ", function (err, result, fields) {

            if (!err && result[0] != undefined) {

                callback(result, t('text_chef_get_working_hours_succ'),1);
            }
            else{
                callback(true, t('text_chef_get_working_hours_fail'),1);
            }
        })   
    },

/*=============================================================================================================================
        Add Or Update Food Speciality
=============================================================================================================================*/

    add_update_food_speciality: function(req,callback){
       

        var query = con.query("SELECT * FROM tbl_chef_food_speciality WHERE user_id = '"+req.login_user_id+"' ", function (err, specialityResult, fields) {

            var params  = {
                food_type_id : req.food_type_id,
            };

            /* Already Added Speciality Update Details  */
            if (!err && specialityResult[0] != undefined) {

                var query = con.query("UPDATE tbl_chef_food_speciality SET ? WHERE user_id = '"+req.login_user_id+"' ", params, function (err, result, fields) {

                    callback(true, t('text_chef_add_update_food_speciality_succ'),1);
                    
                });
            }
            /* Add Speciality Details */
            else{
                params.user_id = req.login_user_id;

                var query = con.query('INSERT tbl_chef_food_speciality SET ? ', params, function (err, result, fields) {

                    callback(true, t('text_chef_add_update_food_speciality_succ'),1);
                })
            }
        })   
    },

/*=============================================================================================================================
        User Login
=============================================================================================================================*/

    login_details: function(req,callback){

        var query = con.query("SELECT * FROM tbl_user where email = '"+req.email+"' AND role = 'Chef' ", function (err, result, fields) {
            //console.log(result[0]);
            
            if (!err) {

                if (result[0] != undefined){

                    var dec_password = cryptoLib.decrypt(result[0].password, shaKey, process.env.ENC_IV);
                    if(req.password == dec_password){
                        var flag = 1;
                    }
                    else{
                        var flag = 0;
                    }

                    if(flag == 1){
                        if(result[0].is_active == '1' && result[0].is_verify == '1') {

                            /* Update Details */
                            var user  = {
                                language: req.language,
                                login: 'login',
                                is_online: '1',
                                last_login : moment().format('YYYY-MM-DD HH:mm'),
                            };

                            con.queryAsync("UPDATE tbl_user SET ? WHERE id = '"+result[0].id+"' ", user);
    
                            Chef.update_device_info(req,result[0].id,function(token){

                                Chef.chef_details(result[0].id,function(response,err){

                                    response.token = token;
                                    callback(response, t('text_customer_login_success'),1);

                                }); // chef_details

                            }); // update_device_info
                        }
                        else if(result[0].is_verify == '0') {

                            Chef.update_device_info(req,result[0].id,function(token){

                                Chef.chef_details(result[0].id,function(response,err){

                                    response.token = token;
                                    callback(response, t('text_customer_login_verification'),4);

                                }); // chef_details

                            }); // update_device_info
                            
                        }
                        else{
                            callback(null, t('text_customer_login_inactive'),3);
                        }
                    }
                    else{
                        callback(null, t('text_customer_login_fail'),0);
                    }//end else
                    
                }
                else{
                    callback(null, t('text_customer_login_fail'),0);

                }//end else
            }
            else {
                callback(null, t('text_customer_login_fail'),0);
            }

        });//end query
    },

/*=============================================================================================================================
        Send or Resend OTP
=============================================================================================================================*/

    send_otp: function(req, callback){

        // var OTP = Math.floor(1000 + Math.random() * 9000);
        var OTP = '1234';

        var query = con.query("SELECT * FROM tbl_user_otp_details where mobile_number = '"+req.mobile_number+"' ", function (err, result, fields) {

            if(!err && result[0] != undefined){

                con.query('UPDATE tbl_user_otp_details SET ? WHERE id = "'+result[0].id+'" ', {otp: OTP}, function (err, result, fields) {

                    req.OTP = OTP;
                    common.send_otp_number(req,function(msg, code){
                        callback(true, msg, code);
                    })

                })
            }
            else {

                var params  = {
                    code: req.code,
                    mobile_number: req.mobile_number,
                    otp: OTP
                }
                var query = con.query('INSERT tbl_user_otp_details SET ? ', params, function (err, result, fields) {

                    req.OTP = OTP;
                    common.send_otp_number(req,function(msg, code){
                        callback(true, msg, code);
                    })
                })
            }
        });

    },


/*=============================================================================================================================
        Send or Resend OTP
=============================================================================================================================*/

    verify_otp: function(req, callback){

        con.query("SELECT * FROM tbl_user_otp_details where mobile_number = '"+req.mobile_number+"' AND otp = '"+req.otp+"' ", function (err, result, fields) {

            if(!err && result[0] != undefined){

                var query = con.query("DELETE FROM tbl_user_otp_details WHERE id = '"+result[0].id+"' ", function (err, result, fields) {
                
                    callback(true, t('text_customer_otp_verify_succ'),1);
                    
                })
            }
            else {
                callback(true, t('text_customer_otp_verify_fail'),0);
            }
        });

    },


/*=============================================================================================================================
        Chef Details
=============================================================================================================================*/

    chef_details: function(req,callback){
        var response = {};
        var query = con.query("SELECT u.* FROM tbl_user u WHERE u.id = '"+req+"' ", function (err, result, fields) {
            //console.log(result)
            if (!err) {

                result[0].image = process.env.image_base_url+process.env.USER_IMAGE+result[0].image;
                Chef.chef_food_speciality(req, function(speciality){

                    result[0].food_speciality = speciality;

                    Chef.chef_document(req, function(documents){

                        Chef.chef_certificate(req, function(certificate){

                            result[0].documents = documents;
                            result[0].certificate = certificate;

                            callback(result[0], t('text_chef_details_succ'),1);
                        })

                    })
                })
            }
            else {
                callback(null, t('text_chef_details_fail'), 0);
            }
        });
    },



/*=============================================================================================================================
        Chef Food Speciality
=============================================================================================================================*/

    chef_food_speciality: function(req, callback){
        
        var response = {};
        con.query("SELECT * FROM tbl_chef_food_speciality WHERE user_id = '"+req+"' ", function (err, result, fields) {
            // console.log(result)
            if (!err && result[0] != undefined) {

                con.query("SELECT *,CONCAT('"+process.env.image_base_url+process.env.FOOD_TYPE+"','',image) as image FROM tbl_food_type WHERE id IN ("+result[0].food_type_id+") ", function (err1, result1, fields) {
                    
                    if (!err1) {

                        callback(result1, t('text_food_type_list'),1);
                    }
                    else {
                        callback([], t('text_food_type_list'), 1);
                    }
                });
            }
            else{
                callback([], t('text_food_type_list'), 1);
            }
        })
    },


/*=============================================================================================================================
        Chef Document
=============================================================================================================================*/

    chef_document: function(req, callback){
        
        con.query("SELECT id,id as document_id,CONCAT('"+process.env.image_base_url+process.env.DOCUMENT+"','',document) as document FROM tbl_chef_document WHERE user_id =  '"+req+"' ", function (err1, result1, fields) {
            
            if (!err1) {

                callback(result1, t('text_document_list'),1);
            }
            else {
                callback([], t('text_document_list'), 1);
            }
        });
            
    },

/*=============================================================================================================================
        Chef Certificate
=============================================================================================================================*/

    chef_certificate: function(req, callback){
        
        con.query("SELECT id,id as certificate_id,CONCAT('"+process.env.image_base_url+process.env.CERTIFICATE+"','',certificate) as certificate FROM tbl_chef_certificate WHERE user_id =  '"+req+"' ", function (err1, result1, fields) {
            
            if (!err1) {

                callback(result1, t('text_certificate_list'),1);
            }
            else {
                callback([], t('text_certificate_list'), 1);
            }
        });
            
    },


/*=============================================================================================================================
        Edit Profile
=============================================================================================================================*/

    edit_profile: function(req,callback){
        
        /* Update Details */
        var params  = {
            name: req.name,
            email: req.email,
            address: req.address,
            latitude: req.latitude,
            longitude: req.longitude,
        };

        if (req.image != undefined && req.image != '') {
            params.image = req.image;
        }

        con.query('UPDATE tbl_user SET ? WHERE id = "'+req.login_user_id+'" ', params, function (err, result, fields) {

            if (!err) {
                Chef.chef_details(req.login_user_id,function(response,err){

                    callback(response, t('text_customer_edit_profile_succ'), 1);
                })
            }
            else{
                callback(null,t('text_customer_edit_profile_fail'), 0);
            }

        });
    },


/*=============================================================================================================================
        Update Document
=============================================================================================================================*/

    update_document: function(req,callback){
        
        /* Update Details */
        var params  = {
            document: req.document,
        };

        if(req.document_id != undefined && req.document_id != ''){

            con.query('UPDATE tbl_chef_document SET ? WHERE user_id = "'+req.login_user_id+'" AND id = "'+req.document_id+'" ', params, function (err, result, fields) {

                if (!err) {

                    callback(true, t('text_customer_edit_profile_succ'), 1);
                    
                }
                else{
                    callback(null,t('text_customer_edit_profile_fail'), 0);
                }

            });
        }
        else{
            params.user_id = req.login_user_id;
            con.query('INSERT INTO tbl_chef_document SET ? ', params, function (err, result, fields) {
                // console.log(err);
                if (!err) {

                    callback(true, t('text_customer_edit_profile_succ'), 1);
                    
                }
                else{
                    callback(null,t('text_customer_edit_profile_fail'), 0);
                }

            });
        }
    },


/*=============================================================================================================================
        Delete Document
=============================================================================================================================*/

    delete_document: function(req,callback){
        
        /* Update Details */

        if(req.document_id != undefined && req.document_id != ''){

            con.query('DELETE FROM tbl_chef_document WHERE user_id = "'+req.login_user_id+'" AND id = "'+req.document_id+'" ', function (err, result, fields) {

                if (!err) {

                    callback(true, t('text_customer_delete_doc_succ'), 1);
                    
                }
                else{
                    callback(null,t('text_customer_delete_doc_fail'), 0);
                }

            });
        }
        else{
            callback(null,t('text_customer_delete_doc_fail'), 0);
        }
    },

/*=============================================================================================================================
        Update Certificate
=============================================================================================================================*/

    update_certificate: function(req,callback){
        
        /* Update Details */
        var params  = {
            certificate: req.certificate,
        };

        if(req.certificate_id != undefined && req.certificate_id != ''){

            con.query('UPDATE tbl_chef_certificate SET ? WHERE user_id = "'+req.login_user_id+'" AND id = "'+req.certificate_id+'" ', params, function (err, result, fields) {

                if (!err) {

                    callback(true, t('text_customer_edit_profile_succ'), 1);
                    
                }
                else{
                    callback(null,t('text_customer_edit_profile_fail'), 0);
                }

            });
        }
        else{
            params.user_id = req.login_user_id;
            con.query('INSERT INTO tbl_chef_certificate SET ? ', params, function (err, result, fields) {
                // console.log(err);
                if (!err) {

                    callback(true, t('text_customer_edit_profile_succ'), 1);
                    
                }
                else{
                    callback(null,t('text_customer_edit_profile_fail'), 0);
                }

            });
        }
    },

/*=============================================================================================================================
        Change Password
=============================================================================================================================*/

    change_password: function(req,callback){

        Chef.chef_details(req.login_user_id,function(response,err){

            if (response != undefined){
                var dec_password = cryptoLib.decrypt(response.password, shaKey, process.env.ENC_IV);

                /* Compare Password */
                if(dec_password == req.old_password) {

                    /* Update Password */
                    var params  = {
                        password: cryptoLib.encrypt(req.new_password, shaKey, process.env.ENC_IV)
                    };

                    con.query('UPDATE tbl_user SET ? WHERE id = "'+req.login_user_id+'" ', params, function (err, result, fields) {
                    
                        callback(response, t('text_customer_change_password_success'),1);
                    })
                }
                else{
                    callback(null, t('text_customer_change_password_fail'),0);
                } //end else
            }
            else{
                callback(null, t('text_customer_change_password_fail'),0);
            }

        })
    },


/*=============================================================================================================================
        Forgot Password
=============================================================================================================================*/

    forgot_password: function(req,callback){
        //console.log(req);

        var query = con.query("SELECT * FROM tbl_user where email = '"+req.email+"' AND role = 'Chef' ", function (err, user, fields) {
            if (!err) {
                
                if (user[0] != undefined){
                    
                    if(user[0].login_type == 'S' && user[0].is_active == '1' && user[0].is_verify == '1') {
                       
                        /* Update Password */
                        var new_password = Math.random().toString(36).replace('0.', '');
                        
                        var params  = {
                            password: cryptoLib.encrypt(new_password, shaKey, process.env.ENC_IV)
                        };

                        con.query('UPDATE tbl_user SET ? WHERE id = "'+user[0].id+'" ', params, function (err, result, fields) {
                    
                            user[0].password = new_password;
                            callback(user[0], t('text_customer_forgot_password_success'),1);
                        })
                       
                    }
                    else if (user[0].login_type != 'S'){
                        callback(null, t('text_customer_forgot_password_role'),0);
                    }
                    else if (user[0].is_verify == '0'){
                        callback(null, t('text_customer_login_verification'),0);
                    }
                    else if (user[0].is_active == '0'){
                        callback(null, t('text_customer_login_inactive'),0);
                    }
                    else{
                        callback(null, t('text_customer_forgot_password_fail1'),0);
                    } //end else
                    
                }
                else{
                    callback(null, t('text_customer_forgot_password_fail'),0);
                }//end else
            } // err if
            else {
                callback(null, t('text_customer_forgot_password_fail1'),0);
            } // err else
        });
         
    },


/*=============================================================================================================================
        Change Language
=============================================================================================================================*/

    change_language: function(req,callback){

        var params  = {
            language : req.language,
        };

        //update query
        con.query('UPDATE tbl_user SET ? WHERE id = "'+req.login_user_id+'" ', params, function (err, result, fields) {

            if (!err) {
                callback(null, t('text_change_language_succ'), 1);
            }
            else {
                callback(null, t('text_change_language_fail'), 0);
            }

        });
    },


/*=============================================================================================================================
        Logout
=============================================================================================================================*/

    logout: function(req, callback){

        var params  = {
            login : 'logout',
            is_online : '0',
        };

        //update query
        con.query('UPDATE tbl_user SET ? WHERE id = "'+req.login_user_id+'" ', params, function (err, result, fields) {

            if (!err) {
                var query = con.query("DELETE FROM tbl_user_device WHERE user_id = '"+req.login_user_id+"' ", function (err, result, fields) {
                    callback(null, t('text_user_logout'), 1);
                })
            }
            else {
                callback(null, t('text_user_logout_fail'), 0);
            }

        });
    },

/*=============================================================================================================================
        Deactivate Account
=============================================================================================================================*/

    deactivate_account: function(req, callback){

        var params  = {
            login : 'logout',
            is_online : '0',
        };

        //update query
        con.query('UPDATE tbl_user SET ? WHERE id = "'+req.login_user_id+'" ', params, function (err, result, fields) {

            if (!err) {
                var query = con.query("DELETE FROM tbl_user_device WHERE user_id = '"+req.login_user_id+"' ", function (err, result, fields) {
                    callback(null, t('text_user_logout'), 1);
                })
            }
            else {
                callback(null, t('text_user_logout_fail'), 0);
            }

        });
    },

/*=============================================================================================================================
        User Details
=============================================================================================================================*/

    api_user_list: function(callback){
        User.find({},'-request -friends -block', function(err, user) {
            if (!err) {
                callback(user, t('text_user_details_succ'),1);
            }
            else {
                callback(null, t('text_user_details_fail'),0);
            }
        });
    },


/*=============================================================================================================================
    Contact Us
=============================================================================================================================*/

    contact_us: function(req,callback){

        var params = {
                user_id: req.login_user_id,
                subject: req.subject,
                description: req.description,
            }
        var query = con.query('INSERT tbl_contact_details SET ? ', params, function (err, result, fields) {
            if (err){
                callback(null,t('text_contact_us_fail'),1);
            }else{

                callback(null,t('text_contact_us_succ'),1);
            }
        });
        
    },


/*=============================================================================================================================
        Food Type List
=============================================================================================================================*/

    food_type_list: function(callback){
        var response = {};
        con.query("SELECT *,CONCAT('"+process.env.image_base_url+process.env.FOOD_TYPE+"','',image) as image FROM tbl_food_type WHERE is_active = '1' ", function (err, result, fields) {
            //console.log(result)
            if (!err) {

                callback(result, t('text_food_type_list'),1);
            }
            else {
                callback(null, t('text_food_type_list'), 0);
            }
        });
    },



/*=============================================================================================================================
        Add Menu Category
=============================================================================================================================*/

    add_menu_category: function(req, callback){

        con.query(`SELECT * FROM tbl_menu_category 
            WHERE category LIKE '`+req.category+`' AND user_id = '`+req.login_user_id+`' AND is_active = '1' `, function (err, result, fields) {
            //console.log(result)
            if (!err && result[0] == undefined) {
                
                var params  = {
                        user_id: req.login_user_id,
                        category : req.category,
                    };
                var query = con.query('INSERT tbl_menu_category SET ? ', params, function (err1, result1, fields) {

                    if (!err1 && result1.affectedRows) {
                        params.id = result1.insertId;
                        callback(params ,t('text_chef_add_menu_category_succ'), 1);
                    }
                    else{
                        callback(null, t('text_chef_add_menu_category_fail1'), 0);
                    }
                });
            }
            else{
                callback(null, t('text_chef_add_menu_category_fail'), 0);
            }
        });
         
    },


/*=============================================================================================================================
        Delete Menu Category
=============================================================================================================================*/

    delete_menu_category: function(req, callback){

        var params  = {
                is_active: '0',
            };
        con.query(`UPDATE tbl_menu_category SET ? 
                WHERE user_id = '`+req.login_user_id+`' AND 
                    id = '`+req.id+`' `, params, function (err, result, fields) {

            if (!err) {

                con.query(`UPDATE tbl_menu SET ? 
                        WHERE user_id = '`+req.login_user_id+`' AND 
                            menu_category_id = '`+req.id+`' `, params, function (err1, result1, fields) {

                    if (!err1) {
                        callback(true ,t('text_chef_delete_menu_succ'), 1);
                    }
                    else{
                        callback(null, t('text_chef_delete_menu_fail'), 0);
                    }
                });
            }
            else{
                callback(null, t('text_chef_delete_menu_fail'), 0);
            }
        });
            
         
    },


/*=============================================================================================================================
        Menu Category List
=============================================================================================================================*/

    menu_category_list: function(req, callback){

        var response = {};
        con.query(`SELECT id, user_id, category FROM tbl_menu_category 
            WHERE is_active = '1' AND user_id = '`+req.login_user_id+`' `, function (err, result, fields) {
            //console.log(result)
            if (!err) {

                callback(result, t('text_chef_menu_category_list_succ'),1);
            }
            else {
                callback(null, t('text_chef_menu_category_list_fail'), 2);
            }
        });
    },


/*=============================================================================================================================
        Add Menu
=============================================================================================================================*/

    add_menu: function(req, callback){

        var params  = {
                user_id: req.login_user_id,
                menu_category_id : req.menu_category_id,
                dish_name : req.dish_name,
                dish_price : req.dish_price,
                currency : '$',
                dish_image : req.dish_image,
                description : req.description,
            };
        var query = con.query('INSERT tbl_menu SET ? ', params, function (err1, result1, fields) {

            if (!err1 && result1.affectedRows) {
                params.id = result1.insertId;
                callback(params ,t('text_chef_add_menu_succ'), 1);
            }
            else{
                callback(null, t('text_chef_add_menu_fail'), 0);
            }
        });
            
         
    },



/*=============================================================================================================================
        Edit Menu
=============================================================================================================================*/

    edit_menu: function(req, callback){

        var params  = {
                user_id: req.login_user_id,
                menu_category_id : req.menu_category_id,
                dish_name : req.dish_name,
                dish_price : req.dish_price,
                currency : '$',
                dish_image : req.dish_image,
                description : req.description,
            };
        var query = con.query(`UPDATE tbl_menu SET ? 
                WHERE user_id = '`+req.login_user_id+`' AND 
                    id = '`+req.dish_id+`' `, params, function (err1, result1, fields) {

            if (!err1) {
                params.id = req.dish_id;
                callback(params ,t('text_chef_edit_menu_succ'), 1);
            }
            else{
                callback(null, t('text_chef_edit_menu_fail'), 0);
            }
        });
            
         
    },


/*=============================================================================================================================
        Delete Menu
=============================================================================================================================*/

    delete_menu: function(req, callback){

        var params  = {
                is_active: '0',
            };
        con.query(`UPDATE tbl_menu SET ? 
                WHERE user_id = '`+req.login_user_id+`' AND 
                    id = '`+req.dish_id+`' `, params, function (err1, result1, fields) {

            if (!err1) {
                callback(true ,t('text_chef_delete_menu_succ'), 1);
            }
            else{
                callback(null, t('text_chef_delete_menu_fail'), 0);
            }
        });
            
         
    },

/*=============================================================================================================================
        Make Available
=============================================================================================================================*/

    make_available: function(req, callback){

        var params  = {
                is_chef_available: req.is_chef_available,
            };
        con.query(`UPDATE tbl_user SET ? 
                WHERE id = '`+req.login_user_id+`' `, params, function (err1, result1, fields) {

            if (!err1) {
                callback(params ,t('text_chef_available_succ'), 1);
            }
            else{
                callback(null, t('text_chef_available_fail'), 0);
            }
        });
            
         
    },


/*=============================================================================================================================
        Menu Category List
=============================================================================================================================*/

    menu_list: function(req, callback){

        var response = {};
        con.query(`SELECT m.*,m.id as dish_id,CONCAT('`+process.env.image_base_url+process.env.DISH_IMAGE+`','',dish_image) as dish_image, category
            FROM tbl_menu  m
            JOIN tbl_menu_category c ON m.menu_category_id = c.id
            WHERE m.is_active = '1' AND m.menu_category_id = '`+req.menu_category_id+`' AND m.user_id = '`+req.login_user_id+`'
            ORDER BY m.id DESC 
            LIMIT `+req.limit+`, `+req.per_page+` `, function (err, result, fields) {
            //console.log(result)
            if (!err && result[0] != undefined) {

                callback(result, t('text_chef_menu_list_succ'),1);
            }
            else {
                callback(null, t('text_chef_menu_list_fail'), 2);
            }
        });
    },


/*=============================================================================================================================
    Order List
=============================================================================================================================*/

    order_list: function(req,callback){

        con.query(`SELECT o.*,o.id as order_id,c.name,CONCAT('`+process.env.image_base_url+process.env.USER_IMAGE+`','',c.image) as image
            FROM tbl_order o
            JOIN tbl_user c ON o.user_id = c.id
            WHERE o.chef_id = "`+req.login_user_id+`" AND o.is_active = '1' AND status = "`+req.status+`"
            ORDER BY o.id DESC
            LIMIT `+req.limit+`, `+req.per_page+`  `, function (err, result, fields) {
            //console.log(query.sql);
            if (!err) {
                
                if (result[0] !== undefined){

                    callback(result, t('text_my_order_list_succ'),1);
                }
                else{
                    callback(null,t('text_my_order_list_fail'),2);    
                }
            }
            else {
                callback(null,t('text_my_order_list_fail'),2);
            }
        });
    },


/*=============================================================================================================================
    Order Details
=============================================================================================================================*/

    order_details: function(req,callback){

        var response = {};
        con.query(`SELECT o.*,o.id as order_id,c.name,c.image,c.address,c.rating,c.code, c.mobile_number
            FROM tbl_order o
            JOIN tbl_user c ON o.user_id = c.id
            WHERE o.id = "`+req.order_id+`" `, function (err, result, fields) {
            //console.log(query.sql);
            if (!err) {
                
                if (result[0] !== undefined){
                    result[0].image = process.env.image_base_url+process.env.USER_IMAGE+result[0].image;

                    Chef.order_dish_details(req.order_id,function(response){

                        result[0].order_dish_details = response;
                        callback(result[0], t('text_order_details_succ'),1);
                    })
                }
                else{
                    callback(null,t('text_order_details_fail'),0);    
                }
            }
            else {
                callback(null,t('text_order_details_fail'),0);
            }
        });
    },

    order_dish_details: function(order_id, callback){

        var response = {};
        con.query(`SELECT o.*,dish_name,currency,CONCAT('`+process.env.image_base_url+process.env.DISH_IMAGE+`','',dish_image) as dish_image,(price * qty) as dish_sub_total
            FROM tbl_order_details  o 
            JOIN tbl_menu m ON o.dish_id = m.id
            WHERE o.order_id = '`+order_id+`' `, function (err, result, fields) {
            //console.log(result)
            if (!err) {

                callback(result);
            }
            else {
                callback(null);
            }
        });
    },

/*=============================================================================================================================
        Approve or Reject Order
=============================================================================================================================*/

    approve_reject_order: function(req,callback){
        
        var query = con.query(`SELECT o.*,u.name FROM tbl_order o JOIN tbl_user u ON o.chef_id = u.id
            WHERE o.id = '`+req.order_id+`' AND o.chef_id = '`+req.login_user_id+`' `, function (err, result, fields) {
            
            if (!err && result[0] != undefined) 
            {
                /* Check Order is in Request State */
                if(result[0].status == 'Request'){

                    var params = {
                        request_status: req.status,
                    }

                    /* Request for Approved */
                    if(req.status == 'Approved'){


                        params.status = 'Preparing';
                        con.query('UPDATE tbl_order SET ? WHERE id = "'+req.order_id+'" ', params, function (err1, result1, fields) {

                            /* Send Push Notification */
                            var push_params = {
                                message: t('text_notify_order_status',{ status:params.status.toLowerCase(), chef: result[0].name}),
                                user_id : result[0].user_id,
                                tag: 'order_status',
                                params: {
                                    user_id: result[0].user_id,
                                    action_id: req.order_id,
                                    notification_lang_tag: 'text_notify_order_status',
                                    type: params.status
                                }
                            }
                            
                            common.prepare_notification(result[0].user_id,'CUSTOMER',push_params);

                            callback(true,t('text_chef_approve_reject_succ',{ field: req.status}), 1);
                        })

                    }
                    /* Request for Rejected */
                    else{

                        var paymentObject = {
                            charge: result[0].transaction_id,
                        }

                        stripe.createChargeRefund(paymentObject,function(refund, refundmsg,refundcode){

                            if (refund != null) {

                                params.status = 'Cancelled';
                                params.cancelled_by = 'Chef';
                                params.cancel_reason = req.cancel_reason;
                                params.payment_status = 'Refund';
                                params.refund_amount = result[0].grand_total;
                                params.transaction_id = refund.id;
                                con.query('UPDATE tbl_order SET ? WHERE id = "'+req.order_id+'" ', params, function (err1, result1, fields) {

                                    /* Send Push Notification */
                                    var push_params = {
                                        message: t('text_notify_order_status',{ status:params.status.toLowerCase(), chef: result[0].name}),
                                        user_id : result[0].user_id,
                                        tag: 'order_status',
                                        params: {
                                            user_id: result[0].user_id,
                                            action_id: req.order_id,
                                            notification_lang_tag: 'text_notify_order_status',
                                            type: req.status
                                        }
                                    }
                                    
                                    common.prepare_notification(result[0].user_id,'CUSTOMER',push_params);

                                    callback(true,t('text_chef_approve_reject_succ',{ field: req.status}), 1);
                                })
                            }
                            else{
                                callback(null,t('text_chef_approve_reject_order_fail',{ field: req.status}), 0)
                            }
                        })
                    }

                } // end if
                else{
                    callback(null,t('text_chef_approve_reject_order_already_accept',{ field: result[0].status}), 0)
                }
            }
            else {
                callback(null,t('text_chef_approve_reject_order_fail',{ field: req.status}), 0)
            }
        });
    },



/*=============================================================================================================================
        Change Status
=============================================================================================================================*/

    change_status: function(req,callback){
        
        var query = con.query(`SELECT o.*,u.name FROM tbl_order o JOIN tbl_user u ON o.chef_id = u.id
            WHERE o.id = '`+req.order_id+`' AND o.chef_id = '`+req.login_user_id+`' `, function (err, result, fields) {
            //console.log(result);
            if (!err && result[0] != undefined) 
            {
                /* Request for Ready */
                if(req.status == 'Ready'){

                    /* Check Order in Preparing Status */
                    if(result[0].status == 'Preparing'){

                        var params = {
                            status: req.status,
                        }

                        con.query('UPDATE tbl_order SET ? WHERE id = "'+req.order_id+'" ', params, function (err1, result1, fields) {

                            /* Send Push Notification */
                            var push_params = {
                                message: t('text_notify_order_status',{ status:req.status.toLowerCase(), chef: result[0].name}),
                                user_id : result[0].user_id,
                                tag: 'order_status',
                                params: {
                                    user_id: result[0].user_id,
                                    action_id: req.order_id,
                                    notification_lang_tag: 'text_notify_order_status',
                                    type: req.status
                                }
                            }
                            
                            common.prepare_notification(result[0].user_id,'CUSTOMER',push_params);

                            callback(true,t('text_chef_change_status_succ',{ field: req.status}), 1);
                        })

                    }
                    /* If not in Preparing status then unable to Change As Ready */
                    else{
                        callback(true,t('text_chef_change_status_fail',{ field: req.status}), 0);
                    }

                } // end if
                else if(req.status == 'Completed'){

                    /* Check Order in Ready Status */
                    if(result[0].status == 'Ready'){

                        var params = {
                            status: req.status,
                        }

                        con.query('UPDATE tbl_order SET ? WHERE id = "'+req.order_id+'" ', params, function (err1, result1, fields) {

                            /* Send Push Notification */
                            var push_params = {
                                message: t('text_notify_order_status',{ status:req.status.toLowerCase(), chef: result[0].name}),
                                user_id : result[0].user_id,
                                tag: 'order_status',
                                params: {
                                    user_id: result[0].user_id,
                                    action_id: req.order_id,
                                    notification_lang_tag: 'text_notify_order_status',
                                    type: req.status
                                }
                            }
                            
                            common.prepare_notification(result[0].user_id,'CUSTOMER',push_params);

                            callback(true,t('text_chef_change_status_succ',{ field: req.status}), 1);
                        })

                    }
                    /* If not in Ready status then unable to Change As Ready */
                    else{
                        callback(true,t('text_chef_change_status_fail',{ field: req.status}), 0);
                    }

                } // end if
                else{
                    callback(true,t('text_chef_change_status_fail',{ field: req.status}), 0);
                }
            }
            else {
                callback(true,t('text_chef_change_status_fail',{ field: req.status}), 0);
            }
        });
    },


/*=============================================================================================================================
    My Earning List
=============================================================================================================================*/

    my_earning_list: function(req,callback){

        con.query(`SELECT o.id as order_id,o.order_datetime,o.order_no,u.name,o.chef_earning as grand_total
            FROM tbl_order o
            JOIN tbl_user u ON o.user_id = u.id
            WHERE o.chef_id = "`+req.login_user_id+`" AND o.is_active = '1' AND status = "Completed" AND o.payment_status = 'Completed'
            ORDER BY o.id DESC
            LIMIT `+req.limit+`, `+req.per_page+`  `, function (err, result, fields) {
            //console.log(query.sql);
            if (!err) {
                
                if (result[0] !== undefined){

                    callback(result, t('text_my_earning_list_succ'),1);
                }
                else{
                    callback(null,t('text_my_earning_list_fail'),2);    
                }
            }
            else {
                callback(null,t('text_my_earning_list_fail'),2);
            }
        });
    },

    earning_count: function(req,callback){

        con.query(`SELECT sum(o.chef_earning) as total
            FROM tbl_order o
            JOIN tbl_user u ON o.user_id = u.id
            WHERE o.chef_id = "`+req.login_user_id+`" AND o.is_active = '1' AND status = "Completed" AND o.payment_status = 'Completed'
             `, function (err, result, fields) {
            //console.log(query.sql);
            if (!err) {
                
                if (result[0] !== undefined){

                    callback(result[0].total, t('text_my_earning_list_succ'),1);
                }
                else{
                    callback(0,t('text_my_earning_list_fail'),1);    
                }
            }
            else {
                callback(0,t('text_my_earning_list_fail'),1);
            }
        });
    },

/*=============================================================================================================================
    Get Settings
=============================================================================================================================*/

    get_setting: function(callback){

        var data = {};
        con.query(`SELECT s.*
            FROM tbl_setting_details s
            WHERE s.attribute_name IN ('min_price','max_price') `, function (err, result, fields) {
            //console.log(query.sql);
            if (!err) {
                
                if (result[0] != undefined){

                    asyncLoop(result, function (item, next) {

                        data[item.attribute_name] = item.attribute_value;
                        next();

                    }, function () {
                        callback(data, t('text_get_settings_succ'),1);
                    });
                }
                else{
                    callback(null,t('text_get_settings_succ'),2);    
                }
            }
            else {
                callback(null,t('text_get_settings_succ'),2);
            }
        });
    },



/*=============================================================================================================================
    Review Alert
=============================================================================================================================*/

    review_alert: function(req, callback){
        
        var response = [];

        con.query(`SELECT o.id as order_id,user_id,chef_id,c.name,TIME_FORMAT(TIMEDIFF(NOW(),o.arrival_time), '%H:00') AS TimeDiff
                FROM tbl_order o
                JOIN tbl_user c ON o.user_id = c.id
                WHERE o.is_active = "1" AND o.chef_id = "`+req.login_user_id+`" AND o.status = "Completed" AND o.is_customer_review = "0"
                HAVING TimeDiff >= "01:00"
                ORDER BY o.insertdate DESC `, function (err, result, fields) {
            //console.log(query.sql);
            if (!err) {
                
                if (result[0] !== undefined){

                    callback(result, t('text_review_list_succ'), 1);
                }
                else{
                    callback(null, t('text_review_list_fail'), 0); 
                }
            }
            else {
                callback(null, t('text_review_list_fail'), 0);
            }
        });
    },


/*=============================================================================================================================
    Give Review
=============================================================================================================================*/

    give_review: function(req,callback){
        
        /* If Rate and Review Provided */
        if( (req.rating != 0 && req.review != undefined && req.review != '') || 
            (req.rating == 0 && req.review != undefined && req.review != '') || 
            (req.rating != 0 && (req.review == undefined || req.review == '') ) 
        ){
            con.query("SELECT rr.* FROM tbl_customer_rating_review rr WHERE rr.order_id = '"+req.order_id+"' AND rr.user_id = '"+req.user_id+"' ", function (err, result, fields) {
                //console.log(result);
                if (!err) 
                {
                    /* Already review the order */
                    if (result[0] != undefined)
                    {
                        callback(null,t('text_give_review_fail'), 0);
                    }
                    else{
                        
                        var params  = {
                            chef_id: req.login_user_id,
                            order_id: req.order_id,
                            user_id : req.user_id,
                            rating: req.rating,
                            review: (req.review != undefined && req.review != '')?req.review:'',
                        };

                        con.query("INSERT INTO tbl_customer_rating_review SET ? ", params, function (err, avg_result, fields) {

                            con.queryAsync("UPDATE tbl_order SET ? WHERE id = '"+req.order_id+"' ", {is_customer_review: '1'} );

                            callback(true,t('text_give_review_succ'), 1);                            
                        });

                    } // end else
                }// if end
                else {
                    callback(null,t('text_give_review_fail1'), 0)
                } // end else
            });
        } // if end
        else{
            con.query("UPDATE tbl_order SET ? WHERE id = '"+req.order_id+"' ", {is_customer_review: '2'});

            callback(true,t('text_give_review_skip'), 1)
        }
            
    },


/*=============================================================================================================================
        Chef rate Review List
=============================================================================================================================*/

    chef_rate_review_list: function(req, callback){

        var response = [];
        

        con.query(`SELECT cr.*,u.name,CONCAT('`+process.env.image_base_url+process.env.USER_IMAGE+`','',image) as image,TIME_FORMAT(TIMEDIFF(NOW(),cr.updatetime), '%H:00') AS TimeDiff
            FROM tbl_chef_rating_review cr
            JOIN tbl_user u ON cr.user_id = u.id
            WHERE cr.chef_id = '`+req.login_user_id+`' AND u.is_active = '1' AND u.is_verify = '1' AND cr.is_active = '1'
            HAVING TimeDiff >= "72:00"
            LIMIT `+req.limit+`, `+req.per_page+` `, function (err, result, fields) {
                
            if (!err) {
                if (result[0] != undefined){

                    callback(result,t('text_review_list_succ'),1);
                }
                else{
                    callback(response, t('text_review_list_fail'), 2);
                }
            }
            else {
                callback(response, t('text_review_list_fail'), 2);
            }
        });
    },



}

module.exports = Chef;
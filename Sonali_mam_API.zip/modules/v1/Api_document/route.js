var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');
var common = require('../../../config/common');
var customer_model = require('../Customer/customer_model');

// Language file load
const { t } = require('localizify');

//console.log(globals);
app = express();
var router = express.Router();// get an instance of the express Router

//set the template engine ejs
  app.set('view engine', 'ejs')

//routes
router.get('/user_list', (req, res) => {

  customer_model.api_user_list(function(response){
    res.render(path.join(__dirname+'/user_list.ejs'), { data: response })
  })
  
})

//routes
router.get('/customer_faq', (req, res) => {

res.render(path.join(__dirname+'/faq.ejs'))
})

//routes
router.get('/customer_terms_and_condition', (req, res) => {

res.render(path.join(__dirname+'/terms_and_condition.ejs'))
})

//routes
router.get('/privacy_policy', (req, res) => {

res.render(path.join(__dirname+'/privacy_policy.ejs'))
})

//routes
router.get('/chef_faq', (req, res) => {

res.render(path.join(__dirname+'/faq.ejs'))
})

//routes
router.get('/chef_terms_and_condition', (req, res) => {

res.render(path.join(__dirname+'/terms_and_condition.ejs'))
})

  module.exports = router;
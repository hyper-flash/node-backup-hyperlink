const Validator = require('Validator');
const common = require('../../../config/common');
const express    = require('express');        // call express
const multer    = require('multer');
const moveFile = require('move-file');
var path = require('path');
const router = express.Router();// get an instance of the express Router
// Language file load
const localizify = require('localizify');
const { t } = require('localizify');

/* define upload for image upload */

var storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'public/upload/')
    },
    filename: (req, file, cb) => {
        var ext = path.extname(file.originalname);

        cb(null, file.fieldname + '-' + Date.now()+ext)
    }
});
var upload = multer({storage: storage});


/*=============================================================================================================================
    Upload Image
=============================================================================================================================*/
    router.post("/image_upload",upload.single('image'), function (req, res) {
        //Image Upload Code 
        
        var image = req.file.filename;

        (async () => {
            await moveFile('public/upload/'+image, 'public/'+process.env[req.body.type]+image);
        })();

        response_data = {
            code: 1,
            message: t('image_upload_success'),
            data: {image:image}
        };

        common.encryption(response_data, function (response) {
            res.status(200);
            res.json(response);
        })

    });


module.exports = router;
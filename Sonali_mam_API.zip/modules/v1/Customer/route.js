const Validator = require('Validator');
const common = require('../../../config/common');
const express    = require('express');        // call express
const template_data = require('../../../config/template');
const router = express.Router();// get an instance of the express Router
// Language file load
const localizify = require('localizify');
const { t } = require('localizify');

const customer_model = require('./customer_model');

/*=============================================================================================================================
    Unique Details Check
=============================================================================================================================*/

    router.post("/unique_details_check", function (req, res) {

        //request method encryption
        common.decryption(req, function (request) {
            localizify.setLocale(request.login_language);

            var rules = {
                email: 'required',
                mobile_number: 'required',
            }

            const messages = {
                'required': t('required')
            }

            var v = Validator.make(request, rules, messages, {
                'email': t('field_email'),
                'mobile_number': t('field_mobile_number')
            })

            if (v.fails()) {

                var Validator_errors = v.getErrors();

                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };

                common.encryption(response_data, function (responseData) {
                    res.status(200);
                    res.json(responseData);
                })
            } else {

                var unique_key = {
                    'email': request.email,
                    'mobile_number': request.mobile_number
                };

                customer_model.check_unique(unique_key, function (response, msg, code) {

                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data, function (response) {
                        res.status(200);
                        res.json(response);
                    })

                }); //check_unique
            } //else
        }); //end decryption
    });

/*=============================================================================================================================
    User Registration
=============================================================================================================================*/

    router.post("/signup",function(req,res){

        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);

            var rules = {
                name: 'required',
                email: 'required|email',
                password: 'required',
                code: 'required',
                mobile_number: 'required',
                address: 'required',
                language: 'required',
                latitude:'',
                longitude:'',
                device_type: 'required',
                device_token:'required',
                uuid:'required',
                os_version:'required',
                device_name:'required',
                model_name:'required',
                ip:'',
            }

            const messages = {
                'required': t('required'),
                'email': t('email')
            }

            var v = Validator.make(request, rules, messages, 
                { 'name': t('field_name'),
                'email': t('field_email') ,
                'password': t('field_password') ,
                'code': t('field_country_code') ,
                'mobile_number': t('field_mobile_number') ,
                'address': t('field_address') ,
                'language': t('field_language'),
                'latitude': t('field_latitude') ,
                'longitude': t('field_longitude') , 
                'device_type': t('field_device_type') ,
                'device_token': t('field_device_token') ,
                'uuid': t('field_uuid') ,
                'os_version': t('field_os_version') ,
                'device_name': t('field_device_name') ,
                'model_name': t('field_model_name') ,
                'ip': t('field_ip')})
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
                
                //process.exit();
                
                var unique_key = {'email':request.email,'mobile_number':request.mobile_number};
                customer_model.check_unique(unique_key,function(response, msg, code){
                    
                    if (response == false) {

                        response_data = {
                            code: 0,
                            message: msg
                        };
                        common.encryption(response_data,function(response){
                            res.status(200);
                            res.json(response);
                        })
                        
                    }
                    else {
                        
                        customer_model.signup(request,function(response, msg, code){
                    
                            response_data = {
                                code: code,
                                message: msg
                            };

                            if (code == 1) {
                                response_data.data = response;
                            }

                            common.encryption(response_data,function(responseData){
                                res.status(200);
                                res.json(responseData);
                            })
                        });//signup
                    }//end else

            });//check_unique
                
            }//else
        });//end decryption
    });


/*=============================================================================================================================
            Login
=============================================================================================================================*/

    router.post("/login",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                email: 'required|email',
                password: 'required',
                language: 'required',
                device_type: 'required',
                device_token:'required',
                uuid:'required',
                os_version:'required',
                device_name:'required',
                model_name:'required',
                ip:'',
            }

            const messages = {
                'required': t('required'),
                'email': t('email')
            }

            var v = Validator.make(request, rules, messages, 
                { 'email': t('field_email'),
                    'password': t('field_password') ,
                    'language': t('field_language'),
                    'device_type': t('field_device_type') ,
                    'device_token': t('field_device_token') ,
                    'uuid': t('field_uuid') ,
                    'os_version': t('field_os_version') ,
                    'device_name': t('field_device_name') ,
                    'model_name': t('field_model_name') ,
                    'ip': t('field_ip')
            })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                customer_model.login_details(request,function(response, msg, code){
                    //console.log(response)

                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })

                });//end login_details
                
            }//end else
        });//end function decryption
    });


/*=============================================================================================================================
            Send OTP
=============================================================================================================================*/

    router.post("/send_otp",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                code: 'required',
                mobile_number: 'required',
            }

            const messages = {
                'required': t('required')
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'code': t('field_code') ,
                    'mobile_number': t('field_mobile_number') ,
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
                
                customer_model.send_otp(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//send_otp
                    
            }//else
        });//end decryption
    });


/*=============================================================================================================================
            Verify OTP
=============================================================================================================================*/

    router.post("/verify_otp",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                code: 'required',
                mobile_number: 'required',
                otp: 'required',
            }

            const messages = {
                'required': t('required')
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'code': t('field_code') ,
                    'mobile_number': t('field_mobile_number') ,
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: '0',
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
                
                customer_model.verify_otp(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//verify_otp
                    
            }//else
        });//end decryption
    });


/*=============================================================================================================================
            Customer Details
=============================================================================================================================*/

    router.get("/customer_details",function(req,res){
        
        localizify.setLocale(req.login_language);
        customer_model.customer_details(req.login_user_id,function(response, msg, code){
            response_data = {
                code: code,
                message: msg,
            };

            if (code == 1) {
                response_data.data = response;
            }

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        });
    });


/*=============================================================================================================================
            Edit profile
=============================================================================================================================*/

    router.post("/edit_profile",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                name: 'required',
                address: 'required',
                latitude:'',
                longitude:'',
            }

            const messages = {
                'required': t('required'),
                'email': t('email')
            }

            var v = Validator.make(request, rules, messages,
                { 'name': t('field_name'),
                    'address': t('field_address') ,
                    'latitude': t('field_latitude') ,
                    'longitude': t('field_longitude'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
                
                customer_model.edit_profile(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//edit_profile
                    
            }//else
        });//end decryption
    });


/*=============================================================================================================================
            Change user password
=============================================================================================================================*/

    router.post("/change_password",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                old_password: 'required',
                new_password: 'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 'old_password': t('field_old_password'),
                    'new_password': t('field_new_password')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.change_password(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code != 0) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//change_password
            }//else
        });//end decryption
    });



/*=============================================================================================================================
            Change user language
=============================================================================================================================*/

    router.post("/change_language",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                language: 'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 'language': t('field_language'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.change_language(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code != 0) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//change_language
            }//else
        });//end decryption
    });


/*=============================================================================================================================
            Update Device Info
=============================================================================================================================*/

    router.post("/update_device_info",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                device_type: 'required',
                device_token:'required',
                uuid:'required',
                os_version:'required',
                device_name:'required',
                model_name:'required',
                ip:'',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                	'device_type': t('field_device_type') ,
	                'device_token': t('field_device_token') ,
	                'uuid': t('field_uuid') ,
	                'os_version': t('field_os_version') ,
	                'device_name': t('field_device_name') ,
	                'model_name': t('field_model_name') ,
	                'ip': t('field_ip')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.change_device_info(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//change_device_info
            }//else
        });//end decryption
    });

/*=============================================================================================================================
            Forgot Password
=============================================================================================================================*/

    router.post("/forgot_password",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            
            var rules = {
                email: 'required|email',
            }

            const messages = {
                'required': t('required'),
                'email': t('email')
            }

            var v = Validator.make(request, rules, messages,
                { 'email': t('field_email')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.forgot_password(request,function(response, msg, code){
            
                    if(code == 0){

                        response_data = {
                            code: code,
                            message: msg,
                        };

                        common.encryption(response_data,function(response){
                            res.status(200);
                            res.json(response);
                        })
                        
                    }
                    else {
                        template_data.forgot_password(response,function(result){

                            //console.log(response);
                            var subject = 'Application Forgot Password';
                            common.send_email(subject,request.email,result,function(result){
                                response_data = {
                                    code: code,
                                    message: msg
                                };

                                common.encryption(response_data,function(response){
                                    res.status(200);
                                    res.json(response);
                                })
                            })  // Send Email
                        }); // template making
                    }//end else
                });//forgot_password
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Contact Us
=============================================================================================================================*/

    router.post("/contact_us",function(req,res){

        //request method encryption
        common.decryption(req,function(request){
            localizify.setLocale(request.login_language);
            
            var rules = {
                subject: 'required',
                description: 'required'
            }

            const messages = {
                'required': t('required')
            }

            var v = Validator.make(request, rules, messages,{'subject': t('field_subject'), 'description': t('field_description')})
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                customer_model.contact_us(request,function(response, msg, code){

                    customer_model.customer_details(request.login_user_id,function(user){

                        request.name = user['name'];
                        request.email = user['email'];
                        request.mobile_number = user['mobile_number'];

                        template_data.contact_us_link(request,function(result){

                            // console.log(result);
                            var subject = t('text_contact_email_subject',{app:process.env.APP_NAME});
                            common.send_email(subject,process.env.FROM_EMAIL,result,function(result){
                                response_data = {
                                    code: code,
                                    message: msg,
                                };

                                common.encryption(response_data,function(response){
                                    res.status(200);
                                    res.json(response);
                                })
                            })  // Send Email
                            
                        }); // template making 
                    })
                    

                });//end contact_us
                
            }//end else
        });//end function decryption
    });


/*=============================================================================================================================
            Logout
=============================================================================================================================*/

    router.get("/logout",function(req,res){
        
        localizify.setLocale(req.login_language);
        customer_model.logout(req,function(response, msg, code){

            response_data = {
                code: code,
                message: msg,
            };

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        })//end logout User
    });


/*=============================================================================================================================
            Deactivate Account
=============================================================================================================================*/

    router.get("/deactivate_account",function(req,res){
        
        localizify.setLocale(req.login_language);
        customer_model.deactivate_account(req,function(response, msg, code){

            response_data = {
                code: code,
                message: msg,
            };

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        })//end deactivate_account
    });


/*=============================================================================================================================
            Food Type List
=============================================================================================================================*/

    router.get("/food_type_list",function(req,res){
        
        localizify.setLocale(req.login_language);
        customer_model.food_type_list(function(response, msg, code){
            response_data = {
                code: code,
                message: msg,
            };

            if (code == 1) {
                response_data.data = response;
            }

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        });
    });


/*=============================================================================================================================
        Near By Chef List
=============================================================================================================================*/

    router.post("/near_by_chef_list",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                search_text:'',
                page: 'required|numeric',
                latitude:'required',
                longitude:'required',
                food_type_id: '',
                current_time: ''
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'page': t('field_page'),
                    'latitude': t('field_latitude') ,
                	'longitude': t('field_longitude') , 
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                if (request.page == '0' || request.page == undefined) {
                    request.page = 1
                }

                request.per_page = process.env.PER_PAGE;

                request.limit = ((request.page - 1) * request.per_page)
        
                customer_model.near_by_chef_list(request,function(response, msg, code){
                
                    customer_model.cart_count(request,function(count_response, msg1, code1){

                        response_data = {
                            code: code,
                            message: msg,
                            data: []
                        };

                        response_data.data = Object.assign({},{count:count_response});

                        if (code == 1) {
                            response_data.data = Object.assign({},response_data.data, {data:response});
                        }

                        common.encryption(response_data,function(response){
                            res.status(200);
                            res.json(response);
                        })
                    })
                });//near_by_chef_list
            }//else
        });//end decryption
    });



/*=============================================================================================================================
        Featured Chef List
=============================================================================================================================*/

    router.post("/featured_chef_list",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                latitude:'required',
                longitude:'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'latitude': t('field_latitude') ,
                    'longitude': t('field_longitude') , 
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.featured_chef_list(request,function(response, msg, code){
                
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }
                    
                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//featured_chef_list
            }//else
        });//end decryption
    });


/*=============================================================================================================================
            Save as Favorite Or Unfavorite
=============================================================================================================================*/

    router.post("/favorite_unfavorite_chef",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                chef_id: 'required|numeric',
                type: 'required|in:favorite,unfavorite',
            }

            const messages = {
                'required': t('required'),
                'numeric' : t('numeric')
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'chef_id': t('field_chef_id'),
                    'type': t('field_type')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                customer_model.favorite_unfavorite_chef(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })

                })//end favorite_unfavorite_chef
                
            }//end else
        });//end function decryption
    });


/*=============================================================================================================================
        Favorite Chef List
=============================================================================================================================*/

    router.post("/favorite_chef_list",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                page: 'required|numeric',
                latitude:'required',
                longitude:'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'page': t('field_page'),
                    'latitude': t('field_latitude') ,
                	'longitude': t('field_longitude') , 
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                if (request.page == '0' || request.page == undefined) {
                    request.page = 1
                }

                request.per_page = process.env.PER_PAGE;

                request.limit = ((request.page - 1) * request.per_page)
        
                customer_model.favorite_chef_list(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//favorite_chef_list
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Chef Details
=============================================================================================================================*/

    router.post("/chef_details",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                chef_id: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'chef_id': t('field_chef_id'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                request.page = 1
                request.per_page = process.env.PER_PAGE;

                request.limit = ((request.page - 1) * request.per_page)
        
                customer_model.chef_details(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//chef_details
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Chef rate Review List
=============================================================================================================================*/

    router.post("/chef_rate_review_list",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                chef_id: 'required|numeric',
                page: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'chef_id': t('field_chef_id'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                request.per_page = process.env.PER_PAGE;

                request.limit = ((request.page - 1) * request.per_page)
        
                customer_model.chef_rate_review_list(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//chef_rate_review_list
            }//else
        });//end decryption
    });

/*=============================================================================================================================
        Customer rate Review List
=============================================================================================================================*/

    router.post("/customer_rate_review_list",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                page: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'page': t('field_page'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                request.per_page = process.env.PER_PAGE;

                request.limit = ((request.page - 1) * request.per_page)
        
                customer_model.customer_rate_review_list(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//customer_rate_review_list
            }//else
        });//end decryption
    });

/*=============================================================================================================================
        Menu Category List
=============================================================================================================================*/

    router.post("/menu_category_list",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                chef_id: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'chef_id': t('field_chef_id'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.menu_category_list(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//menu_category_list
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Menu List
=============================================================================================================================*/

    router.post("/menu_list",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
            	chef_id: 'required|numeric',
                menu_category_id: 'required|numeric',
                page: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                	'chef_id': t('field_chef_id'),
                    'menu_category_id': t('field_category'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                if (request.page == '0' || request.page == undefined) {
                    request.page = 1
                }

                request.per_page = process.env.PER_PAGE;

                request.limit = ((request.page - 1) * request.per_page)
        
                customer_model.menu_list(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//menu_list
            }//else
        });//end decryption
    });



/*=============================================================================================================================
        Card List
=============================================================================================================================*/

    router.get("/card_list",function(req,res){
        
        localizify.setLocale(req.login_language);
        customer_model.card_list(req, function(response, msg, code){
            response_data = {
                code: code,
                message: msg,
            };

            if (code == 1) {
                response_data.data = response;
            }

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        });
    });



/*=============================================================================================================================
        Add Card Details
=============================================================================================================================*/

    router.post("/add_card",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                card_holder_name: 'required',
                card_number: 'required',
                expiration_date: 'required',
                cvv: 'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'card_holder_name': t('field_card_holder_name'),
                    'card_number': t('field_card_number'),
                    'expiration_date': t('field_expiration_date'),
                    'cvv': t('field_cvv'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.add_card(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//add_card
            }//else
        });//end decryption
    });

/*=============================================================================================================================
        Set Default Card Details
=============================================================================================================================*/

    router.post("/set_default_card",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                card_id: 'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'card_id': t('field_card_id'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.set_default_card(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//set_default_card
            }//else
        });//end decryption
    });

/*=============================================================================================================================
        Delete Card
=============================================================================================================================*/

    router.post("/delete_card",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                card_id: 'required|numeric'
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'card_id': t('field_card_id')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.delete_card(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//delete_card
            }//else
        });//end decryption
    });

/*=============================================================================================================================
        Add to Cart
=============================================================================================================================*/

    router.post("/add_to_cart",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                dish_id: 'required|numeric',
                chef_id: 'required|numeric',
                qty: 'required|numeric',
                cart_detail_id: '',
                notes: ''
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'dish_id': t('field_dish_id'),
                    'qty': t('field_qty'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.add_to_cart(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//add_to_cart
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Remove From Cart
=============================================================================================================================*/

    router.post("/remove_from_cart",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                cart_detail_id: 'required|numeric'
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'cart_detail_id': t('field_cart_detail_id'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.remove_from_cart(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//remove_from_cart
            }//else
        });//end decryption
    });

/*=============================================================================================================================
        Cart Details
=============================================================================================================================*/

    router.get("/cart_details",function(req,res){
        
        localizify.setLocale(req.login_language);
        customer_model.get_cart(req, function(response, msg, code){
            response_data = {
                code: code,
                message: msg,
            };

            if (code == 1) {
                response_data.data = response;
            }

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        });
    });


/*=============================================================================================================================
        Place Order
=============================================================================================================================*/

    router.post("/place_order",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                card_id: 'required|numeric',
                arrival_time: 'required',
                is_utensils: 'required|in:0,1',
                is_tip: 'required|in:0,1',
                tip_amount: ''
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'card_id': t('field_card_id')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.place_order(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }
                    
                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//place_order
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Order Details
=============================================================================================================================*/

    router.post("/order_details",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                order_id: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'order_id': t('field_order_id')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.order_details(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }
                    
                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//order_details
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        My Order
=============================================================================================================================*/

    router.post("/my_order_list",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                type: 'required|in:past,current',
                page: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'type': t('field_type'),
                    'page': t('field_page'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                if (request.page == '0' || request.page == undefined) {
                    request.page = 1
                }

                request.per_page = process.env.PER_PAGE;

                request.limit = ((request.page - 1) * request.per_page)
        
                customer_model.my_order_list(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }

                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//my_order_list
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Review Alert
=============================================================================================================================*/

    router.get("/review_alert",function(req,res){
        
        localizify.setLocale(req.login_language);
        customer_model.review_alert(req, function(response, msg, code){
            response_data = {
                code: code,
                message: msg,
            };

            if (code == 1) {
                response_data.data = response;
            }

            common.encryption(response_data,function(response){
                res.status(200);
                res.json(response);
            })
        });
    });


/*=============================================================================================================================
        Give Review
=============================================================================================================================*/

    router.post("/give_review",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                order_id:'required|numeric',
                chef_id: 'required|numeric',
                rating: 'required|numeric',
                review: '',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'order_id': t('field_order_id')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.give_review(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };
                    
                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//give_review
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Cancel Order
=============================================================================================================================*/

    router.post("/cancel_order",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                order_id:'required|numeric',
                cancel_reason: 'required',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                {
                    'order_id': t('field_order_id')
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{
        
                customer_model.cancel_order(request,function(response, msg, code){
            
                    response_data = {
                        code: code,
                        message: msg,
                    };
                    
                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//cancel_order
            }//else
        });//end decryption
    });


/*=============================================================================================================================
        Near By Chef List
=============================================================================================================================*/

    router.post("/notification_list",function(req,res){
        
        //request method encryption
        common.decryption(req,function(request){

            localizify.setLocale(request.login_language);
            
            var rules = {
                page: 'required|numeric',
            }

            const messages = {
                'required': t('required'),
            }

            var v = Validator.make(request, rules, messages,
                { 
                    'page': t('field_page'),
                })
            
            if (v.fails()) {

                var Validator_errors = v.getErrors();
                
                for (var key in Validator_errors) {
                    error = Validator_errors[key][0];
                    break;
                }

                response_data = {
                    code: 0,
                    message: error
                };
                common.encryption(response_data,function(responseData){
                    res.status(200);
                    res.json(responseData);
                })
            }
            else{

                if (request.page == '0' || request.page == undefined) {
                    request.page = 1
                }

                request.per_page = process.env.PER_PAGE;

                request.limit = ((request.page - 1) * request.per_page)
        
                customer_model.notification_list(request,function(response, msg, code){
                
                    response_data = {
                        code: code,
                        message: msg,
                    };

                    if (code == 1) {
                        response_data.data = response;
                    }
                    
                    common.encryption(response_data,function(response){
                        res.status(200);
                        res.json(response);
                    })
                });//notification_list
            }//else
        });//end decryption
    });


module.exports = router;
const con = require('../../../config/database');
const stripe = require('../../../config/stripe');
const common = require('../../../config/common');
const asyncLoop = require('node-async-loop');
const _randomhash = require('crypto-toolkit').RandomHash('base64-urlsafe');
const cryptoLib = require('cryptlib');
const shaKey = cryptoLib.getHashSha256(process.env.ENC_KEY, 32);
const moment = require('moment');
// Language file load
const { t } = require('localizify');

// get an instance of the express Router
var Customer = {

/*=============================================================================================================================
    User Registration
=============================================================================================================================*/

    signup: function(req,callback){

        var cimage = 'default-user.png';

        if (req.image != undefined && req.image != '') {
            var cimage = req.image;
        }

        var loginParams = {
            name: req.name,
            email: req.email,
            code: req.code,
            mobile_number: req.mobile_number,
            password: (req.password != undefined && req.password != '') ? cryptoLib.encrypt(req.password, shaKey, process.env.ENC_IV) : '',
            address: req.address,
            latitude: req.latitude,
            longitude: req.longitude,
            language: req.language,
            image: cimage,
            login_type: 'S',
            is_online: '1',
            last_login: moment().format('YYYY-MM-DD HH:mm'),
            role: 'Customer',
            is_verify: '1'
        };

        /* Insert Login Details */
        con.query('INSERT INTO tbl_user SET ?', loginParams, function (err, result, _fields) {
            if (!err) {
                if (result.affectedRows) {

                    stripe.create_customer({ email: req.email },function(resCustomer){

                        if (resCustomer != undefined) {

                            con.queryAsync("UPDATE tbl_user SET ? WHERE id = '"+result.insertId+"' ", {stripe_customer_id:resCustomer.id});
                        }

                        Customer.update_device_info(req,result.insertId,function(token){

                            Customer.customer_details(result.insertId,function(response,err){
                                response.token = token;

                                callback(response,t('text_customer_signup_success'),1);

                            }); // customer_details

                        }); // update_device_info
                    })

                } // if(result.affectedRows)
                else {
                    callback(null, t('text_customer_signup_fail'), 0);
                } // else
            } else {
                callback(null, t('text_customer_signup_fail'), 0);
            }

        });
    },


/*=============================================================================================================================
        Check Unique
=============================================================================================================================*/

    check_unique: function (unique_key, callback) {

        var len = Object.keys(unique_key).length;
        var i = 1;

        asyncLoop(unique_key, function (item, next) {
            //console.log(item);
            // Get object key with: item.key 
            // Get associated value with: item.value
            if (item.value != '' && item.value != undefined) {
                var query = con.query("SELECT * FROM tbl_user WHERE role = 'Customer' AND " + item.key + " = ? ", item.value, function (err, result, _fields) {

                    if (!err) {
                        if (result[0] == undefined) {
                            if (len == i) {
                                callback(true, t('text_rest_unique_succ'), 1);
                                return;
                            }
                        } else {
                            //console.log(item.key);
                            callback(false, t('text_rest_already_taken', {
                                field: item.key.replace("_", " ")
                            }), 0);
                            return;
                        }
                    } else {
                        callback(false, t('text_rest_already_taken', {
                            field: item.key.replace("_", " ")
                        }), 0);
                        return;

                    }
                    i++;
                    next();
                });
            } else {
                i++;
                next();
            }

        }, function () {
            callback();
        });
    },



/*=============================================================================================================================
        Update Device Info
=============================================================================================================================*/

    update_device_info: function(req,user_id,callback){
        //console.log(req);
        var query = con.query("DELETE FROM tbl_user_device WHERE user_id = '"+user_id+"' ", function (err, result, fields) {
            var token = _randomhash.sha256();
            var params  = {
                    user_id: user_id,
                    token : token,
                    device_type: req.device_type,
                    device_token: req.device_token,
                    uuid: req.uuid,
                    os_version: req.os_version,
                    device_name: req.device_name,
                    model_name: req.model_name,
                    ip: req.ip
                };
            var query = con.query('INSERT tbl_user_device SET ? ', params, function (err, result, fields) {
                callback(token);
            });
        });
         
    },


/*=============================================================================================================================
        Update Device Info
=============================================================================================================================*/

    change_device_info: function(req,callback){
        
        var params  = {
                device_type: req.device_type,
                device_token: req.device_token,
                uuid: req.uuid,
                os_version: req.os_version,
                device_name: req.device_name,
                model_name: req.model_name,
                ip: req.ip
            };
        var query = con.query('UPDATE tbl_user_device SET ? WHERE user_id = "'+req.login_user_id+'" ', params, function (err, result, fields) {
            callback(req, t('text_change_device_info'), 1);
        });
         
    },

/*=============================================================================================================================
        User Login
=============================================================================================================================*/

    login_details: function(req,callback){

        var query = con.query("SELECT * FROM tbl_user where email = '"+req.email+"' AND role = 'Customer' ", function (err, result, fields) {
            //console.log(result[0]);
            
            if (!err) {

                if (result[0] != undefined){

                    var dec_password = cryptoLib.decrypt(result[0].password, shaKey, process.env.ENC_IV);
                    if(req.password == dec_password){
                        var flag = 1;
                    }
                    else{
                        var flag = 0;
                    }

                    if(flag == 1){
                        if(result[0].is_active == '1' && result[0].is_verify == '1') {

                            /* Update Details */
                            var user  = {
                                language: req.language,
                                login: 'login',
                                is_online: '1',
                                last_login : moment().format('YYYY-MM-DD HH:mm'),
                            };

                            con.queryAsync("UPDATE tbl_user SET ? WHERE id = '"+result[0].id+"' ", user);
    
                            Customer.update_device_info(req,result[0].id,function(token){

                                Customer.customer_details(result[0].id,function(response,err){

                                    response.token = token;
                                    callback(response, t('text_customer_login_success'),1);

                                }); // customer_details

                            }); // update_device_info
                        }
                        else if(result[0].is_verify == '0') {

                            Customer.update_device_info(req,result[0].id,function(token){

                                Customer.customer_details(result[0].id,function(response,err){

                                    response.token = token;
                                    callback(response, t('text_customer_login_verification'),4);

                                }); // customer_details

                            }); // update_device_info
                            
                        }
                        else{
                            callback(null, t('text_customer_login_inactive'),3);
                        }
                    }
                    else{
                        callback(null, t('text_customer_login_fail'),0);
                    }//end else
                    
                }
                else{
                    callback(null, t('text_customer_login_fail'),0);

                }//end else
            }
            else {
                callback(null, t('text_customer_login_fail'),0);
            }

        });//end query
    },

/*=============================================================================================================================
        Send or Resend OTP
=============================================================================================================================*/

    send_otp: function(req, callback){

        // var OTP = Math.floor(1000 + Math.random() * 9000);
        var OTP = '1234';

        var query = con.query("SELECT * FROM tbl_user_otp_details where mobile_number = '"+req.mobile_number+"' ", function (err, result, fields) {

            if(!err && result[0] != undefined){

                con.query('UPDATE tbl_user_otp_details SET ? WHERE id = "'+result[0].id+'" ', {otp: OTP}, function (err, result, fields) {

                    req.OTP = OTP;
                    common.send_otp_number(req,function(msg, code){
                        callback(true, msg, code);
                    })

                })
            }
            else {

                var params  = {
                    code: req.code,
                    mobile_number: req.mobile_number,
                    otp: OTP
                }
                var query = con.query('INSERT tbl_user_otp_details SET ? ', params, function (err, result, fields) {

                    req.OTP = OTP;
                    common.send_otp_number(req,function(msg, code){
                        callback(true, msg, code);
                    })
                })
            }
        });

    },


/*=============================================================================================================================
        Send or Resend OTP
=============================================================================================================================*/

    verify_otp: function(req, callback){

        con.query("SELECT * FROM tbl_user_otp_details where mobile_number = '"+req.mobile_number+"' AND otp = '"+req.otp+"' ", function (err, result, fields) {

            if(!err && result[0] != undefined){

                var query = con.query("DELETE FROM tbl_user_otp_details WHERE id = '"+result[0].id+"' ", function (err, result, fields) {
                
                    callback(true, t('text_customer_otp_verify_succ'),1);
                    
                })
            }
            else {
                callback(true, t('text_customer_otp_verify_fail'),0);
            }
        });

    },


/*=============================================================================================================================
        Customer Details
=============================================================================================================================*/

    customer_details: function(req,callback){
        var response = {};
        var query = con.query("SELECT u.* FROM tbl_user u WHERE u.id = '"+req+"' ", function (err, result, fields) {
            //console.log(result)
            if (!err) {

                delete result[0].chef_profile_status;
                delete result[0].about_me;
                delete result[0].is_chef_available;
                result[0].image = process.env.image_base_url+process.env.USER_IMAGE+result[0].image;

                Customer.get_total_cart_item(req, function(total_cart_item){

                    result[0].total_cart_item = total_cart_item;
                    callback(result[0], t('text_customer_details_succ'),1);
                    
                }) // get_total_cart_item
            }
            else {
                callback(null, t('text_customer_details_fail'), 0);
            }
        });
    },

    get_total_cart_item: function(req,callback){
        
        var query = con.query("SELECT total_cart_item FROM tbl_cart WHERE user_id = '"+req+"' ", function (err, result, fields) {
            //console.log(result)
            if (!err && result[0] != undefined) {

                callback(result[0].total_cart_item);
            }
            else {
                callback(0);
            }
        });
    },

/*=============================================================================================================================
        Edit Profile
=============================================================================================================================*/

    edit_profile: function(req,callback){
        
        /* Update Details */
        var params  = {
            name: req.name,
            address: req.address,
            latitude: req.latitude,
            longitude: req.longitude,
        };

        if (req.image != undefined && req.image != '') {
            params.image = req.image;
        }

        con.query('UPDATE tbl_user SET ? WHERE id = "'+req.login_user_id+'" ', params, function (err, result, fields) {

            if (!err) {
                Customer.customer_details(req.login_user_id,function(response,err){

                    callback(response, t('text_customer_edit_profile_succ'), 1);
                })
            }
            else{
                callback(null,t('text_customer_edit_profile_fail'), 0);
            }

        });
    },

/*=============================================================================================================================
        Change Password
=============================================================================================================================*/

    change_password: function(req,callback){

        Customer.customer_details(req.login_user_id,function(response,err){

            if (response != undefined){
                var dec_password = cryptoLib.decrypt(response.password, shaKey, process.env.ENC_IV);

                /* Compare Password */
                if(dec_password == req.old_password) {

                    /* Update Password */
                    var params  = {
                        password: cryptoLib.encrypt(req.new_password, shaKey, process.env.ENC_IV)
                    };

                    con.query('UPDATE tbl_user SET ? WHERE id = "'+req.login_user_id+'" ', params, function (err, result, fields) {
                    
                        callback(response, t('text_customer_change_password_success'),1);
                    })
                }
                else{
                    callback(null, t('text_customer_change_password_fail'),0);
                } //end else
            }
            else{
                callback(null, t('text_customer_change_password_fail'),0);
            }

        })
    },


/*=============================================================================================================================
        Forgot Password
=============================================================================================================================*/

    forgot_password: function(req,callback){
        //console.log(req);

        var query = con.query("SELECT * FROM tbl_user where email = '"+req.email+"' AND role = 'Customer' ", function (err, user, fields) {
            if (!err) {
                
                if (user[0] != undefined){
                    
                    if(user[0].login_type == 'S' && user[0].is_active == '1' && user[0].is_verify == '1') {
                       
                        /* Update Password */
                        var new_password = Math.random().toString(36).replace('0.', '');
                        
                        var params  = {
                            password: cryptoLib.encrypt(new_password, shaKey, process.env.ENC_IV)
                        };

                        con.query('UPDATE tbl_user SET ? WHERE id = "'+user[0].id+'" ', params, function (err, result, fields) {
                    
                            user[0].password = new_password;
                            callback(user[0], t('text_customer_forgot_password_success'),1);
                        })
                       
                    }
                    else if (user[0].login_type != 'S'){
                        callback(null, t('text_customer_forgot_password_role'),0);
                    }
                    else if (user[0].is_verify == '0'){
                        callback(null, t('text_customer_login_verification'),0);
                    }
                    else if (user[0].is_active == '0'){
                        callback(null, t('text_customer_login_inactive'),0);
                    }
                    else{
                        callback(null, t('text_customer_forgot_password_fail1'),0);
                    } //end else
                    
                }
                else{
                    callback(null, t('text_customer_forgot_password_fail'),0);
                }//end else
            } // err if
            else {
                callback(null, t('text_customer_forgot_password_fail1'),0);
            } // err else
        });
         
    },


/*=============================================================================================================================
        Change Language
=============================================================================================================================*/

    change_language: function(req,callback){

        var params  = {
            language : req.language,
        };

        //update query
        con.query('UPDATE tbl_user SET ? WHERE id = "'+req.login_user_id+'" ', params, function (err, result, fields) {

            if (!err) {
                callback(null, t('text_change_language_succ'), 1);
            }
            else {
                callback(null, t('text_change_language_fail'), 0);
            }

        });
    },



/*=============================================================================================================================
        Set Notification
=============================================================================================================================*/

    set_notification: function(req,callback){
        //update query
        con.query('UPDATE tbl_user SET ? WHERE id = "'+req.login_user_id+'" ', {notification: req.notification}, function (err, result, fields) {

            if (!err) {
                callback(null, t('text_set_notification_succ'), 1);
            }
            else {
                callback(null, t('text_set_notification_fail'), 0);
            }

        });
    },




/*=============================================================================================================================
    Notification List
=============================================================================================================================*/

    notification_list: function(req,callback){
            
        var response = [];
        
        var query = con.query(`SELECT n.*,u.name,CONCAT('`+process.env.image_base_url+process.env.USER_IMAGE+`','',image) as image
                FROM tbl_notification_details n
                JOIN tbl_order o ON n.action_id = o.id
                JOIN tbl_user u ON o.chef_id = u.id
                WHERE n.user_id = "`+req.login_user_id+`"
                ORDER BY n.id DESC 
                LIMIT `+req.limit+`, `+req.per_page+` `, function (err, result, fields) {
            
            // console.log(query.sql);
            if (!err) {
                
                if (result[0] !== undefined){

                    var row = 0;
                    asyncLoop(result, function (item, next)
                    {
                        result[row].message = t(item.notification_lang_tag,{ status:item.type.toLowerCase(), chef: item.name});
                        row++;
                        next();

                    }, function ()
                    {
                        callback(result, t('text_notification_list_succ'), 1);
                    });
                }
                else{
                    callback(null, t('text_notification_list_fail'), 2); 
                }
            }
            else {
                callback(null, t('text_notification_list_fail'), 2);
            }
        });
    },

/*=============================================================================================================================
        Logout
=============================================================================================================================*/

    logout: function(req, callback){

        var params  = {
            login : 'logout',
            is_online : '0',
        };

        //update query
        con.query('UPDATE tbl_user SET ? WHERE id = "'+req.login_user_id+'" ', params, function (err, result, fields) {

            if (!err) {
                var query = con.query("DELETE FROM tbl_user_device WHERE user_id = '"+req.login_user_id+"' ", function (err, result, fields) {
                    callback(null, t('text_user_logout'), 1);
                })
            }
            else {
                callback(null, t('text_user_logout_fail'), 0);
            }

        });
    },


/*=============================================================================================================================
        Deactivate Account
=============================================================================================================================*/

    deactivate_account: function(req, callback){

        var params  = {
            login : 'logout',
            is_online : '0',
        };

        //update query
        con.query('UPDATE tbl_user SET ? WHERE id = "'+req.login_user_id+'" ', params, function (err, result, fields) {

            if (!err) {
                var query = con.query("DELETE FROM tbl_user_device WHERE user_id = '"+req.login_user_id+"' ", function (err, result, fields) {
                    callback(null, t('text_user_logout'), 1);
                })
            }
            else {
                callback(null, t('text_user_logout_fail'), 0);
            }

        });
    },


/*=============================================================================================================================
        User Details
=============================================================================================================================*/

    api_user_list: function(callback){
        User.find({},'-request -friends -block', function(err, user) {
            if (!err) {
                callback(user, t('text_user_details_succ'),1);
            }
            else {
                callback(null, t('text_user_details_fail'),0);
            }
        });
    },


/*=============================================================================================================================
    Contact Us
=============================================================================================================================*/

    contact_us: function(req,callback){

        var params = {
                user_id: req.login_user_id,
                subject: req.subject,
                description: req.description,
            }
        var query = con.query('INSERT tbl_contact_details SET ? ', params, function (err, result, fields) {
            if (err){
                callback(null,t('text_contact_us_fail'),1);
            }else{

                callback(null,t('text_contact_us_succ'),1);
            }
        });
        
    },


/*=============================================================================================================================
        Food Type List
=============================================================================================================================*/

    food_type_list: function(callback){
        var response = {};
        con.query("SELECT *,CONCAT('"+process.env.image_base_url+process.env.FOOD_TYPE+"','',image) as image FROM tbl_food_type WHERE is_active = '1' ", function (err, result, fields) {
            //console.log(result)
            if (!err) {

                callback(result, t('text_food_type_list'),1);
            }
            else {
                callback(null, t('text_food_type_list'), 0);
            }
        });
    },


/*=============================================================================================================================
        Near By Chef List
=============================================================================================================================*/

    near_by_chef_list: function(req, callback){

        var response = {};
        var food_type_where = '';
        var search_text_where = '';
        var select_distance = ",(6371 * 2 * ASIN(SQRT( POWER(SIN(('"+req.latitude+"' - u.latitude) * pi()/180 / 2), (2) ) + COS('"+req.latitude+"' * pi()/180) * COS(u.latitude * pi()/180) *POWER(SIN(('"+req.longitude+"' - u.longitude) * pi()/180 / 2), (2) ) ))) as distance";

        var current_time = (req.current_time != undefined)?req.current_time:moment().format('hh:mm:ss');

        if(req.food_type_id != undefined && req.food_type_id != ''){

            var food_type_array = req.food_type_id.split(",");
            food_type_where = 'AND (';
            for (var key in food_type_array) {
                
                food_type_where += `FIND_IN_SET('`+food_type_array[key]+`', cs.food_type_id) `+((key == food_type_array.length-1)?``:` OR `);
            }

            food_type_where += `)`;
        }

        if(req.search_text != undefined && req.search_text != ''){
            search_text_where = ` AND u.name LIKE '`+req.search_text+`%' `;
        }

        con.query(`SELECT u.id as chef_id,u.name,u.address,u.latitude, u.longitude, u.rating, u.is_online,CONCAT('`+process.env.image_base_url+process.env.USER_IMAGE+`','',image) as image, wh.available,wh.start_time, wh.end_time `+select_distance+`
            FROM tbl_user u
            JOIN tbl_chef_food_speciality cs ON cs.user_id = u.id
            JOIN tbl_chef_working_hours wh ON wh.user_id = u.id
            WHERE u.is_active = '1' AND u.is_verify = '1' AND u.is_chef_available = '1' AND role = 'Chef' AND wh.days = '`+moment().format('ddd')+`' AND '`+current_time+`' BETWEEN wh.start_time AND wh.end_time
            `+food_type_where+` `+search_text_where+`
            GROUP BY u.id
            HAVING distance <= 50
            ORDER BY distance 
            LIMIT `+req.limit+`, `+req.per_page+` `, function (err, result, fields) {
                
            if (!err) {
                if (result[0] != undefined){

                    asyncLoop(result, function (item, next)
                    {   
                        Customer.food_speciality_details(item.chef_id, function(food_type){

                            Customer.is_favorite_check(req.login_user_id, item.chef_id, function(is_favorite){
                            
                                item.food_type = food_type;
                                item.is_favorite = is_favorite;
                                next();
                            })
                        })

                    }, function ()
                    {
                        callback(result,t('text_customer_near_me_chef_list_succ'),1);
                    });
                }
                else{
                    callback(null, t('text_customer_near_me_chef_list_fail'), 2);
                }
            }
            else {
                callback(null, t('text_customer_near_me_chef_list_fail'), 2);
            }
        });
    },


/*=============================================================================================================================
        Featured Chef List
=============================================================================================================================*/

    featured_chef_list: function(req, callback){

        var response = {};

        var select_distance = ",(6371 * 2 * ASIN(SQRT( POWER(SIN(('"+req.latitude+"' - u.latitude) * pi()/180 / 2), (2) ) + COS('"+req.latitude+"' * pi()/180) * COS(u.latitude * pi()/180) *POWER(SIN(('"+req.longitude+"' - u.longitude) * pi()/180 / 2), (2) ) ))) as distance";

        con.query(`SELECT u.id as chef_id,u.name,u.address,u.latitude, u.longitude, u.rating, u.is_online,CONCAT('`+process.env.image_base_url+process.env.USER_IMAGE+`','',image) as image, wh.available,wh.start_time, wh.end_time `+select_distance+`
            FROM tbl_user u
            JOIN tbl_chef_working_hours wh ON wh.user_id = u.id
            WHERE u.is_active = '1' AND u.is_verify = '1' AND u.is_chef_available = '1' AND role = 'Chef' AND chef_profile_status = '0' AND wh.days = '`+moment().format('ddd')+`'  AND wh.available = '1'
            GROUP BY u.id
            HAVING distance <= 50
            ORDER BY u.rating DESC
            LIMIT 10 `, function (err, result, fields) {

            if (!err) {
                if (result[0] != undefined){

                    asyncLoop(result, function (item, next)
                    {   
                        Customer.food_speciality_details(item.chef_id, function(food_type){

                            Customer.is_favorite_check(req.login_user_id, item.chef_id, function(is_favorite){
                            
                                item.food_type = food_type;
                                item.is_favorite = is_favorite;
                                next();
                            })
                        })

                    }, function ()
                    {
                        callback(result,t('text_customer_featured_chef_list_succ'),1);
                    });
                }
                else{
                    callback(null, t('text_customer_featured_chef_list_fail'), 2);
                }
            }
            else {
                callback(null, t('text_customer_featured_chef_list_fail'), 2);
            }
        });
    },


/*=============================================================================================================================
        Project Service Details
=============================================================================================================================*/

    food_speciality_details: function(chef_id, callback){
        var response = {};
        con.query(`SELECT GROUP_CONCAT(f.name) AS food_type
            FROM tbl_chef_food_speciality cs 
            JOIN tbl_food_type f ON FIND_IN_SET(f.id, cs.food_type_id)
            WHERE cs.user_id = '`+chef_id+`' `, function (err, result, fields) {
            
            if (!err && result[0] != undefined) {

                callback(result[0].food_type);
            }
            else {
                callback('');
            }
        });
    },

/*=============================================================================================================================
        Is Favorite Check
=============================================================================================================================*/
    
    is_favorite_check: function(login_user_id,chef_id,callback){
            
        var is_favorite = 0;

        var query = con.query(`SELECT * FROM tbl_favorite_chef fc 
            WHERE fc.user_id = '`+login_user_id+`' AND fc.chef_id = '`+chef_id+`' `, function (err, result, fields) {
            //console.log(query.sql);
            if (!err) 
            {
                if (result[0] != undefined)
                {
                    is_favorite = 1;
                    callback(is_favorite);
                }
                else{
                    callback(is_favorite);
                }
            }
            else {
                callback(is_favorite);
            }
        });
    },


/*=============================================================================================================================
        Favorite Unfavorite Chef
=============================================================================================================================*/

    favorite_unfavorite_chef: function(req,callback){
        
        var query = con.query(`SELECT fc.* FROM tbl_favorite_chef fc 
            WHERE fc.user_id = '`+req.login_user_id+`' AND fc.chef_id = '`+req.chef_id+`' `, function (err, result, fields) {
            //console.log(result);
            if (!err) 
            {
                /* Request for favorite */
                if (req.type == 'favorite') {
                    /* But user is already favorite */
                    if (result[0] != undefined)
                    {
                        callback(true, t('text_chef_favorite_unfavorite_succ',{ field: req.type.charAt(0).toUpperCase()+ req.type.slice(1)}), 1);
                    }
                    /* If user is not favorite */
                    else{
                        
                        var params  = {
                            user_id: req.login_user_id,
                            chef_id : req.chef_id,
                        };

                        con.query("INSERT INTO tbl_favorite_chef SET ? ", params, function (err1, result1, fields) {
                            callback(true, t('text_chef_favorite_unfavorite_succ',{ field: req.type.charAt(0).toUpperCase()+ req.type.slice(1)}), 1);
                        })
                    
                    } // end else
                } // end if
                else{

                    if (result[0] != undefined)
                    {
                        /* Unfavorite */
                        con.query("DELETE FROM tbl_favorite_chef WHERE user_id = '"+req.login_user_id+"' AND chef_id = '"+req.chef_id+"' ", function (err1, result1, fields) {
                        
                            callback(true, t('text_chef_favorite_unfavorite_succ',{ field: req.type.charAt(0).toUpperCase()+ req.type.slice(1)}), 1);
                        })
                    }
                    else{
                        callback(true, t('text_chef_favorite_unfavorite_succ',{ field: req.type.charAt(0).toUpperCase()+ req.type.slice(1)}), 1);
                    }
                    

                }// end else
            }
            else {
                callback(null,t('text_chef_favorite_unfavorite_fail',{ field: req.type}), 0)
            }
        });
    },


/*=============================================================================================================================
        Favorite Chef List
=============================================================================================================================*/

    favorite_chef_list: function(req, callback){

        var response = {};
        var select_distance = ",(3959 * 2 * ASIN(SQRT( POWER(SIN(('"+req.latitude+"' - u.latitude) * pi()/180 / 2), (2) ) + COS('"+req.latitude+"' * pi()/180) * COS(u.latitude * pi()/180) *POWER(SIN(('"+req.longitude+"' - u.longitude) * pi()/180 / 2), (2) ) ))) as distance";


        con.query(`SELECT u.id as chef_id,u.name,u.address,u.latitude, u.longitude, u.rating, u.is_online,CONCAT('`+process.env.image_base_url+process.env.USER_IMAGE+`','',image) as image, wh.available,wh.start_time, wh.end_time `+select_distance+`
            FROM tbl_favorite_chef fc
            JOIN tbl_user u ON fc.chef_id = u.id
            JOIN tbl_chef_food_speciality cs ON cs.user_id = u.id
            JOIN tbl_chef_working_hours wh ON wh.user_id
            WHERE fc.user_id = '`+req.login_user_id+`' AND u.is_active = '1' AND u.is_verify = '1' AND role = 'Chef' AND wh.days = '`+moment().format('ddd')+`' 
            GROUP BY u.id
            ORDER BY distance
            LIMIT `+req.limit+`, `+req.per_page+` `, function (err, result, fields) {
                
            if (!err) {
                if (result[0] != undefined){

                    asyncLoop(result, function (item, next)
                    {   
                        Customer.food_speciality_details(item.chef_id, function(food_type){

                            Customer.is_favorite_check(req.login_user_id, item.chef_id, function(is_favorite){
                            
                                item.food_type = food_type;
                                item.is_favorite = is_favorite;
                                next();
                            })
                        })

                    }, function ()
                    {
                        // console.log(result);
                        callback(result,t('text_favorite_chef_list_succ'),1);
                    });
                }
                else{
                    callback(null, t('text_favorite_chef_list_fail'), 2);
                }
            }
            else {
                callback(null, t('text_favorite_chef_list_fail'), 2);
            }
        });
    },


/*=============================================================================================================================
        Chef Details
=============================================================================================================================*/

    chef_details: function(req,callback){
        var response = {};
        var query = con.query("SELECT u.* FROM tbl_user u WHERE u.id = '"+req.chef_id+"' ", function (err, result, fields) {
            //console.log(result)
            if (!err) {

                result[0].image = process.env.image_base_url+process.env.USER_IMAGE+result[0].image;
                Customer.is_favorite_check(req.login_user_id, result[0].id, function(is_favorite){

                    Customer.chef_food_speciality(result[0].id, function(speciality){                            

                        Customer.chef_rate_review_list(req, function(rate_review_list){

                            Customer.chef_certificate(result[0].id, function(certificate){

                                delete result[0].password;
                                result[0].is_favorite = is_favorite;
                                result[0].food_speciality = speciality;
                                result[0].rate_review_list = rate_review_list;
                                result[0].certificate = certificate;

                                callback(result[0], t('text_chef_details_succ'),1);
                            })
                        })
                    })
                })
            }
            else {
                callback(null, t('text_chef_details_fail'), 0);
            }
        });
    },

/*=============================================================================================================================
        Chef Certificate
=============================================================================================================================*/

    chef_certificate: function(req, callback){
        
        con.query("SELECT id,id as certificate_id,CONCAT('"+process.env.image_base_url+process.env.CERTIFICATE+"','',certificate) as certificate FROM tbl_chef_certificate WHERE user_id =  '"+req+"' ", function (err1, result1, fields) {
            
            if (!err1) {

                callback(result1, t('text_certificate_list'),1);
            }
            else {
                callback([], t('text_certificate_list'), 1);
            }
        });
            
    },


/*=============================================================================================================================
        Chef Food Speciality
=============================================================================================================================*/

    chef_food_speciality: function(req, callback){
        
        var response = {};
        con.query("SELECT * FROM tbl_chef_food_speciality WHERE user_id = '"+req+"' ", function (err, result, fields) {
            // console.log(result)
            if (!err && result[0] != undefined) {

                con.query("SELECT *,CONCAT('"+process.env.image_base_url+process.env.FOOD_TYPE+"','',image) as image FROM tbl_food_type WHERE id IN ("+result[0].food_type_id+") ", function (err1, result1, fields) {
                    
                    if (!err1) {

                        callback(result1, t('text_food_type_list'),1);
                    }
                    else {
                        callback([], t('text_food_type_list'), 1);
                    }
                });
            }
            else{
                callback([], t('text_food_type_list'), 1);
            }
        })
    },


/*=============================================================================================================================
        Chef rate Review List
=============================================================================================================================*/

    chef_rate_review_list: function(req, callback){

        var response = [];
        

        con.query(`SELECT cr.*,u.name,CONCAT('`+process.env.image_base_url+process.env.USER_IMAGE+`','',image) as image,TIME_FORMAT(TIMEDIFF(NOW(),cr.updatetime), '%H:00') AS TimeDiff
            FROM tbl_chef_rating_review cr
            JOIN tbl_user u ON cr.user_id = u.id
            WHERE cr.chef_id = '`+req.chef_id+`' AND u.is_active = '1' AND u.is_verify = '1' AND cr.is_active = '1'
            HAVING TimeDiff >= "72:00"
            LIMIT `+req.limit+`, `+req.per_page+` `, function (err, result, fields) {
                
            if (!err) {
                if (result[0] != undefined){

                    callback(result,t('text_review_list_succ'),1);
                }
                else{
                    callback(response, t('text_review_list_fail'), 2);
                }
            }
            else {
                callback(response, t('text_review_list_fail'), 2);
            }
        });
    },


/*=============================================================================================================================
        Customer rate Review List
=============================================================================================================================*/

    customer_rate_review_list: function(req, callback){

        var response = [];
        

        con.query(`SELECT cr.*,u.name,CONCAT('`+process.env.image_base_url+process.env.USER_IMAGE+`','',image) as image
            FROM tbl_customer_rating_review cr
            JOIN tbl_user u ON cr.chef_id = u.id
            WHERE cr.user_id = '`+req.login_user_id+`' AND u.is_active = '1' AND u.is_verify = '1' AND cr.is_active = '1'
            LIMIT `+req.limit+`, `+req.per_page+` `, function (err, result, fields) {
                
            if (!err) {
                if (result[0] != undefined){

                    callback(result,t('text_review_list_succ'),1);
                }
                else{
                    callback(response, t('text_review_list_fail'), 2);
                }
            }
            else {
                callback(response, t('text_review_list_fail'), 2);
            }
        });
    },


/*=============================================================================================================================
        Menu Category List
=============================================================================================================================*/

    menu_category_list: function(req, callback){

        var response = {};
        con.query(`SELECT id, user_id, category FROM tbl_menu_category 
            WHERE is_active = '1' AND user_id = '`+req.chef_id+`' `, function (err, result, fields) {
            //console.log(result)
            if (!err && result[0] != undefined) {

                callback(result, t('text_chef_menu_category_list_succ'),1);
            }
            else {
                callback(null, t('text_chef_menu_category_list_fail'), 2);
            }
        });
    },


/*=============================================================================================================================
        Menu Category List
=============================================================================================================================*/

    menu_list: function(req, callback){

        var response = {};
        con.query(`SELECT m.*,m.id as dish_id,m.user_id as chef_id,CONCAT('`+process.env.image_base_url+process.env.DISH_IMAGE+`','',dish_image) as dish_image, category
            FROM tbl_menu  m
            JOIN tbl_menu_category c ON m.menu_category_id = c.id
            WHERE m.is_active = '1' AND m.menu_category_id = '`+req.menu_category_id+`' AND m.user_id = '`+req.chef_id+`'
            ORDER BY m.id DESC 
            LIMIT `+req.limit+`, `+req.per_page+` `, function (err, result, fields) {
            //console.log(result)
            if (!err && result[0] != undefined) {

                callback(result, t('text_chef_menu_list_succ'),1);
            }
            else {
                callback(null, t('text_chef_menu_list_fail'), 2);
            }
        });
    },


/*=============================================================================================================================
    Customer Card List
=============================================================================================================================*/

    card_list: function(req,callback){
        
        query = con.query("SELECT id as card_id, card_number, card_holder_name,is_default FROM tbl_card_detail WHERE user_id = '"+req.login_user_id+"' AND is_active = '1' ", function (err, result, fields) {
            if (!err) {
                if (result[0] !== undefined){

                    callback(result, t('text_customer_card_list_succ'),1);
                }
                else{
                    callback(null, t('text_customer_card_list_fail'),2); 
                }
            }
            else {
                callback(null, t('text_customer_card_list_fail'),2);
            }
        });
    },


/*=============================================================================================================================
        Add Card Details
=============================================================================================================================*/

    add_card: function(req,callback){
            
        Customer.check_customerId(req.login_user_id, function(stripe_customer_id){

            // console.log(stripe_customer_id);
            if(stripe_customer_id != ''){

                let paymentGatewayData = {
                    name            : req.card_holder_name,
                    number          : req.card_number,
                    exp_month       : req.expiration_date.split('/')[0],
                    exp_year        : req.expiration_date.split('/')[1],
                    cvc             : req.cvv
                }

                //add card into stripe 
                stripe.create_card_token(paymentGatewayData,function(resToken, msg, code) {

                    /* Fail Card */
                    if (resToken == undefined) {
                        callback(null,msg, 0);
                    } else {

                        con.query('SELECT * from tbl_card_detail WHERE user_id=' + req.login_user_id + ' AND fingerprint="' + resToken.card.fingerprint + '"', function(err, result) {
                            if (!err && result.length > 0) {
                                callback(null, t('text_customer_card_already_exist'), 0);
                            } else {
                                //bind card with stripe customer
                                stripe.create_source({ customer_id: stripe_customer_id, token: resToken.id },function (resSource, msg, code) {
                                    if (resSource == undefined) {
                                        callback(null,msg, 0);
                                    } else {

                                        /* Make Card as Default Card */
                                        Customer.make_default_card({customer_id: stripe_customer_id, card_id: resToken.card.id, user_id: req.login_user_id},function(code, msg, data){
                                            /* Add Card Details into Database */
                                            var params  = {
                                                card_id: resToken.card.id,
                                                fingerprint: resToken.card.fingerprint,
                                                credit_card_token: resToken.id,
                                                user_id: req.login_user_id,
                                                card_holder_name: req.card_holder_name,
                                                card_number: req.card_number.slice(0, 4)+"x".repeat(req.card_number.length - 8)+req.card_number.slice(-4),
                                                expiration_date: req.expiration_date,
                                                is_default: 1,
                                            };
                                            
                                            query = con.query('INSERT INTO tbl_card_detail SET ?', params, function (err, result, fields) {
                                                //console.log(query.sql);
                                                if (!err) 
                                                {
                                                    /* Insert Card Details */
                                                    if(result.affectedRows) {
                                                        
                                                        callback(result, t('text_customer_add_card_succ'), 1);

                                                    } // if(result.affectedRows)
                                                    else{
                                                        callback(null,t('text_customer_add_card_fail'), 0);
                                                    } // else
                                                }
                                                else {
                                                    callback(null,t('text_customer_add_card_fail'), 0);
                                                }

                                            });
                                        })
                                    }
                                })
                            }
                        })
                    }
                })

            }
            else{
                callback(null,t('text_customer_add_card_fail'), 0);
            }

        })
        
    },

    check_customerId(user_id, callback) {
        Customer.customer_details(user_id,function(result, msg, code){

            if(result.stripe_customer_id == undefined || result.stripe_customer_id == "")
            {
                stripe.create_customer({ email: result.email },function(resCustomer){
                    // console.log(resCustomer);
                    if (resCustomer != undefined) {

                        con.query('UPDATE tbl_user SET ? WHERE id = "'+user_id+'" ', {stripe_customer_id:resCustomer.id}, function (err1, result1, fields) {

                            // console.log(error);
                            callback(resCustomer.id)
                        })
                    } else {
                        callback('')
                    }
                })
            } else {
                callback(result.stripe_customer_id);
            }
        })    
    },

    set_default_card: function(req, callback){

        Customer.check_customerId(req.login_user_id, function(stripe_customer_id){

            if(stripe_customer_id != ''){

                con.query(`SELECT c.*, u.stripe_customer_id FROM tbl_card_detail c
                    JOIN tbl_user u ON c.user_id = u.id
                    WHERE c.id = "`+req.card_id+`" AND c.user_id = "`+req.login_user_id+`" `, function (err, result, fields) {

                    if (!err && result[0] != undefined) {

                        Customer.make_default_card({customer_id: stripe_customer_id, card_id: result[0].card_id, user_id: req.login_user_id},function( data, msg, code){

                            /* Make Card As Default in Database */
                            con.query('UPDATE tbl_card_detail SET ? WHERE id = "'+result[0].id+'" ', {'is_default': 1}, function (err1, result1, fields) {
                                callback(data, msg, code)
                            })
                        })

                    } else {
                        callback(null,t('text_customer_add_card_fail'),0);
                    }
                });
            }
            else{
                callback(null,t('text_customer_add_card_fail'), 0)
            }
        })
    },

    make_default_card: function(req,callback){
        /* Make Card as Default Card */
        stripe.update_source({ customer_id: req.customer_id, card_id: req.card_id },function (resSource, msg, code) {
            if (resSource == undefined) {
                callback(null, msg,0)
            } else {
                /* Set all as default 0 */
                con.query('UPDATE tbl_card_detail SET ? WHERE user_id = "'+req.user_id+'" ', {'is_default': 0}, function (err1, result1, fields) {
                    callback(null,t('text_customer_set_default'),1);
                })
            }
        })
    },

/*=============================================================================================================================
        Delete Card
=============================================================================================================================*/

    delete_card: function(req,callback){

        con.query(`SELECT c.*, u.stripe_customer_id FROM tbl_card_detail c
            JOIN tbl_user u ON c.user_id = u.id
            WHERE c.id = "`+req.card_id+`" AND c.user_id = "`+req.login_user_id+`" `, function (err, result, fields) {

            if (!err && result[0] != undefined) {

                query = con.query("DELETE FROM tbl_card_detail WHERE id = '"+req.card_id+"' AND user_id = '"+req.login_user_id+"' ", function (err1, result1, fields) {
                    if (!err1) 
                    {
                        if(result1.affectedRows) {
                            // Delete Card
                            stripe.delete_source({ customer_id: result[0].stripe_customer_id, card_id: result[0].card_id },function (resSource, msg, code) {
                                
                                    callback(true, t('text_customer_delete_card_succ'), 1);
                                
                                
                            })
                        }
                        else{
                                callback(null,t('text_customer_delete_card_fail1'), 0);
                            }
                    }
                    else {
                        callback(null,t('text_customer_delete_card_fail2'), 0);
                    }
                })
            }
            else{
                callback(null,t('text_customer_delete_card_fail3'), 0);
            }
        })
        
    },


/*=============================================================================================================================
        Cart Count
=============================================================================================================================*/

    cart_count: function(req,callback){

        query = con.query(`SELECT count(c.id) as cart_count
            FROM tbl_cart c
            WHERE c.user_id = '`+req.login_user_id+`' `, function (err, result, fields) {

            if (!err && result[0] != undefined) 
            {
                callback(result[0].cart_count, t('text_customer_cart_count'), 1);
            }
            else {
                callback(0,t('text_customer_cart_count'), 1);
            }
        })
        
    },

/*=============================================================================================================================
        Add Menu Category
=============================================================================================================================*/

    add_to_cart: function(req, callback){

        var cart_id;
        req.spicy_level = (req.spicy_level == undefined)?'Mild':req.spicy_level;

        con.query(`SELECT c.*,u.name as chef_name 
            FROM tbl_cart c
            JOIN tbl_user u ON c.chef_id = u.id
            WHERE c.user_id = '`+req.login_user_id+`' `, function (err, result, fields) {
            // console.log(result);
            
            if(err){

                callback(null, t('text_customer_add_cart_fail'), 0);
            }
            else if(result[0] == undefined) {
                
                var params  = {
                        user_id: req.login_user_id,
                        chef_id: req.chef_id
                    };
                var query = con.query('INSERT tbl_cart SET ? ', params, function (err1, result1, fields) {

                    if (!err1 && result1.affectedRows) {
                        cart_id = result1.insertId;
                        Customer.add_cart_items(req, cart_id, function(status){

                            Customer.get_cart(req,function(cart_details){
                                callback(cart_details ,t('text_customer_add_cart_succ'), 1);
                            })
                        })
                    }
                    else{
                        callback(null, t('text_customer_add_cart_fail'), 0);
                    }
                });
            }
            else if(result[0] != undefined && result[0].chef_id == req.chef_id){

                cart_id = result[0].id;
                Customer.add_cart_items(req, cart_id, function(status){

                    Customer.get_cart(req,function(cart_details){
                        callback(cart_details, t('text_customer_add_cart_succ'), 1);
                    })
                })
            }
            else{
                callback(null, t('text_customer_add_cart_diff_chef',{chef_name:result[0].chef_name}), 0);   
            }
        });
         
    },


    add_cart_items: function(req, cart_id, callback){


        if(req.cart_detail_id != undefined && req.cart_detail_id != ''){
            
            con.query(`SELECT * FROM tbl_cart_details 
            WHERE id = '`+req.cart_detail_id+`' `, function (err, result, fields) {
                if(result[0] != undefined){

                    /* If Both Spicy Level are Same */
                    if(req.spicy_level == result[0].spicy_level){

                        var params  = {
                            qty: req.qty,
                            notes: (req.notes != undefined)?req.notes:''
                        };

                        con.query('UPDATE tbl_cart_details SET ? WHERE id = "'+req.cart_detail_id+'" ', params, function (err1, result1, fields) {
                            callback(1);
                        })
                    } // end if
                    else{

                        con.query(`SELECT * FROM tbl_cart_details 
                            WHERE cart_id = '`+cart_id+`' AND dish_id = '`+req.dish_id+`' AND spicy_level = '`+req.spicy_level+`' `, function (err1, result1, fields) {

                                /* If found with spice level which we need to update than update into this and remove previous cart details entry */
                                if(result1[0] != undefined){

                                    var params  = {
                                        qty: (result1[0].qty+parseInt(req.qty)),
                                        notes: (req.notes != undefined)?req.notes:'',
                                    };

                                    con.query('UPDATE tbl_cart_details SET ? WHERE id = "'+result1[0].id+'" ', params, function (err, result, fields) {

                                        /* Delete Previous One */
                                        con.query("DELETE FROM tbl_cart_details WHERE id = '"+req.cart_detail_id+"' ", function (err1, result1, fields) {
                                            callback(1);
                                        })
                                    })

                                }
                                /* If no spice Level found with same name then update current one */
                                else{
                                    var params  = {
                                        qty: req.qty,
                                        spicy_level: req.spicy_level,
                                        notes: (req.notes != undefined)?req.notes:''
                                    };

                                    con.query('UPDATE tbl_cart_details SET ? WHERE id = "'+req.cart_detail_id+'" ', params, function (err1, result1, fields) {

                                        callback(1);
                                    })
                                }

                        })
                    } // end else

                }
                else{
                    callback(0);
                }
            })            
        } // end if
        /* If cart_details id not pass then add new cart details  */
        else{
            /* Check Item already added or not */
            con.query(`SELECT * FROM tbl_cart_details 
            WHERE cart_id = '`+cart_id+`' AND dish_id = '`+req.dish_id+`' AND spicy_level = '`+req.spicy_level+`' `, function (err1, result1, fields) {

                /* If found with spice level which we need to update than update into this and remove previous cart details entry */
                if(result1[0] != undefined){

                    var params  = {
                        qty: (result1[0].qty+parseInt(req.qty)),
                        notes: (req.notes != undefined)?req.notes:'',
                    };

                    con.query('UPDATE tbl_cart_details SET ? WHERE id = "'+result1[0].id+'" ', params, function (err, result, fields) {

                        callback(1);
                    })
                }
                else{
                    var params  = {
                        cart_id: cart_id,
                        dish_id: req.dish_id,
                        qty: req.qty,
                        spicy_level: req.spicy_level,
                        notes: (req.notes != undefined)?req.notes:'',
                    };
                    var query = con.query('INSERT tbl_cart_details SET ? ', params, function (err1, result1, fields) {

                        callback(1);
                    })
                }
            })

        } // end else
    },

/*=============================================================================================================================
        Remove From Cart
=============================================================================================================================*/

    remove_from_cart: function(req, callback){
        con.query(`SELECT * FROM tbl_cart_details 
            WHERE id = '`+req.cart_detail_id+`' `, function (err, result, fields) {

                if(result[0] != undefined){

                    con.query("DELETE FROM tbl_cart_details WHERE id = '"+req.cart_detail_id+"' ", function (err1, result1, fields) {

                        Customer.get_cart(req,function(cart_details){

                            /* No dish in cart remove cart */
                            if(cart_details == null){

                                con.query("DELETE FROM tbl_cart WHERE id = '"+result[0].cart_id+"' ", function (err2, result2, fields) {

                                    callback(null,t('text_customer_cart_details_fail'), 2);
                                })                                
                            }
                            else{

                                callback(cart_details,t('text_customer_remove_cart_succ'), 1);
                            }

                        })
                    })
                }
                else{
                    callback(null,t('text_customer_remove_cart_fail'), 0);
                }
        })
    },



/*=============================================================================================================================
        Get User Cart Details
=============================================================================================================================*/

    get_cart: function(req, callback){
        var response = {};
        con.query(`SELECT c.*,c.id as cart_id
            FROM tbl_cart  c 
            WHERE c.user_id = '`+req.login_user_id+`' `, function (err, result, fields) {
            //console.log(result)
            if (!err && result[0] != undefined) {

                Customer.get_cart_item_details(result[0].cart_id,function(cart_items){

                    if(cart_items != undefined && cart_items != ''){

                        result[0].sub_total = cart_items.map(o => o.dish_sub_total).reduce((a, c) => { return a + c });
                        result[0].cart_items = cart_items;
                        callback(result[0], t('text_customer_cart_details_succ'),1);
                    }
                    else{
                        callback(null, t('text_customer_cart_details_fail'),2);
                    }
                })

            }
            else {
                callback(null, t('text_customer_cart_details_fail'), 2);
            }
        });
    },


    get_cart_item_details: function(cart_id, callback){

        var response = {};
        con.query(`SELECT c.*,c.id as cart_detail_id,dish_name,currency,dish_price,CONCAT('`+process.env.image_base_url+process.env.DISH_IMAGE+`','',dish_image) as dish_image,(dish_price * qty) as dish_sub_total,m.user_id as chef_id,m.description
            FROM tbl_cart_details  c 
            JOIN tbl_menu m ON c.dish_id = m.id
            WHERE c.cart_id = '`+cart_id+`' `, function (err, result, fields) {
            //console.log(result)
            if (!err) {

                callback(result);
            }
            else {
                callback([]);
            }
        });
    },


/*=============================================================================================================================
        Place Order
=============================================================================================================================*/

    place_order: function(req, callback){

        Customer.get_cart(req, function(cartResult){

            if(cartResult){

                Customer.customer_details(req.login_user_id,function(result, msg, code){

                    if(result.stripe_customer_id != undefined && result.stripe_customer_id != "")
                    {

                        Customer.get_bank_details({chef_id: cartResult.chef_id}, function(bank_details){

                            if (bank_details != null) {

                                common.getSettingsValue('earning',function(earning){


                                    const orderid = require('order-id')('mysecret');
                                    var params  = {
                                        order_no: orderid.generate(),
                                        user_id: req.login_user_id,
                                        chef_id: cartResult.chef_id,
                                        order_datetime: moment().format('YYYY-MM-DD HH:mm:ss'),
                                        arrival_time: req.arrival_time,
                                        total_item: cartResult.total_cart_item,
                                        sub_total: cartResult.sub_total,
                                        delivery_charge: 0,
                                        grand_total: cartResult.sub_total,
                                        status: "Request",
                                        request_status: "Pending",
                                        payment_status: "Pending",
                                        is_utensils: req.is_utensils,
                                        is_tip: (req.is_tip != undefined)?req.is_tip:'0',
                                        tip_amount: (req.tip_amount != undefined && req.tip_amount != '' && req.tip_amount != 0)?req.tip_amount:'0',
                                    };

                                    if(req.tip_amount != undefined && req.tip_amount != '' && req.tip_amount != 0){
                                        params.grand_total = (parseFloat(params.grand_total)+parseFloat(params.tip_amount));
                                    }

                                    params.app_earning = ((params.grand_total * earning )/100);
                                    params.chef_earning = params.grand_total - params.app_earning;

                                    var paymentObject = {
                                        amount: Math.round(params.grand_total * 100),
                                        currency: bank_details.currency,
                                        capture: false,
                                        customer: result.stripe_customer_id,
                                        destination: bank_details.merchant_account_id,
                                        application_fee: Math.round(params.app_earning * 100),
                                        description: "For order: #" + params.order_no
                                    }

                                    stripe.createStripeCharge(paymentObject, function(charge, chargemsg, chargecode) {

                                        if (charge != null) {
                                            
                                            params.transaction_id = charge.id;
                                            con.query('INSERT INTO tbl_order SET ?', params, function (err, result1, fields) {
                                                
                                                if (!err) 
                                                {
                                                    /* Add Order Details */

                                                    Customer.insert_order_details(cartResult.cart_items,result1.insertId,function(){

                                                        /* Empty Cart Details */
                                                        Customer.empty_cart(cartResult.cart_id, function(){

                                                            Customer.order_details({order_id:result1.insertId},function(response){

                                                                /* Send Push Notification */
                                                                var push_params = {
                                                                    message: t('text_notify_order_request',{ customer: result.name}),
                                                                    user_id : cartResult.chef_id,
                                                                    tag: 'order_status',
                                                                    params: {
                                                                        user_id: cartResult.chef_id,
                                                                        action_id: result1.insertId,
                                                                        notification_lang_tag: 'text_notify_order_status',
                                                                        type: 'Pending'
                                                                    }
                                                                }
                                                                
                                                                common.prepare_notification(cartResult.chef_id,'CHEF',push_params);

                                                                callback(response, t('text_place_order_succ'), 1);

                                                            }) // order_details
                                                        }) // empty_cart

                                                    }) // insert_order_details
                                                }
                                                else {
                                                    callback(null, t('text_place_order_fail'), 0);
                                                }

                                            });
                                        }
                                        else{
                                            callback(null, chargemsg, 0);
                                        }
                                    })

                                }) // get settings
                            }
                            else{
                                callback(null, t('text_place_order_fail'), 0);
                            }
                        })
                    }
                    else{
                        callback(null, t('text_place_order_fail'), 0);    
                    }
                })
                
            }
            else{
                callback(null, t('text_place_order_fail'), 0);
            }

        })
         
    },

    captureStripeCharge: function(){
        con.query(`SELECT o.*,TIME_FORMAT(TIMEDIFF(NOW(),o.arrival_time), '%H:00') AS TimeDiff
            FROM tbl_order o
            WHERE  o.status = 'Completed' AND o.payment_status = 'Pending' AND o.transaction_id != ''
            HAVING TimeDiff >= "40:00"
             `, function (err, result, fields) {
                
            if (!err) {
                if (result[0] != undefined){

                    asyncLoop(result, function (item, next)
                    {   
                        stripe.captureStripeCharge(item.transaction_id,function(charge,chargemsg,chargecode){
                            if (charge != null) {

                                con.query('UPDATE tbl_order SET ? WHERE id = "'+item.id+'" ', {'payment_status': 'Completed'}, function (err1, result1, fields) {

                                    next();
                                })
                            }
                            else{
                                console.log(chargemsg);
                                next();
                            }
                        })

                    }, function ()
                    {
                        
                    });
                }
                else{
                    
                }
            }
            else {
                
            }
        });
    },


/*=============================================================================================================================
        Bank Details
=============================================================================================================================*/

    get_bank_details: function(req,callback){
       

        var query = con.query("SELECT * FROM tbl_bank_detail WHERE user_id = '"+req.chef_id+"' ", function (err, result, fields) {

            if (!err && result[0] != undefined) {

                callback(result[0], t('text_chef_get_bank_details_succ'),1);
            }
            else{
                callback(false, t('text_chef_get_bank_details_fail'),0);
            }
        })   
    },


/*=============================================================================================================================
    Insert Order Details
=============================================================================================================================*/

    insert_order_details: function(data,order_id,callback){
        
        //console.log(data);
        var params  = [];

        //console.log(data)
        for (var key in data) {
            
            params.push([order_id,data[key]['dish_id'],data[key]['qty'],data[key]['dish_price'],data[key]['notes'],data[key]['spicy_level']]);
        }

        
        var sql = "INSERT INTO tbl_order_details (order_id,dish_id,qty,price,notes,spicy_level) VALUES ?";
        con.query(sql, [params], function (err, result, fields) {
        //console.log(query.sql);
            callback();

        });
    },



/*=============================================================================================================================
    Order Details
=============================================================================================================================*/

    order_details: function(req,callback){

        var response = {};
        con.query(`SELECT o.*,o.id as order_id,c.name,c.image,c.address,c.rating
            FROM tbl_order o
            JOIN tbl_user c ON o.chef_id = c.id
            WHERE o.id = "`+req.order_id+`" `, function (err, result, fields) {
            //console.log(query.sql);
            if (!err) {
                
                if (result[0] !== undefined){
                    result[0].image = process.env.image_base_url+process.env.USER_IMAGE+result[0].image;

                    Customer.order_dish_details(req.order_id,function(response){

                        result[0].order_dish_details = response;
                        callback(result[0], t('text_order_details_succ'),1);
                    })
                }
                else{
                    callback(null,t('text_order_details_fail'),0);    
                }
            }
            else {
                callback(null,t('text_order_details_fail'),0);
            }
        });
    },

    order_dish_details: function(order_id, callback){

        var response = {};
        con.query(`SELECT o.*,dish_name,currency,CONCAT('`+process.env.image_base_url+process.env.DISH_IMAGE+`','',dish_image) as dish_image,(price * qty) as dish_sub_total
            FROM tbl_order_details  o 
            JOIN tbl_menu m ON o.dish_id = m.id
            WHERE o.order_id = '`+order_id+`' `, function (err, result, fields) {
            //console.log(result)
            if (!err) {

                callback(result);
            }
            else {
                callback(null);
            }
        });
    },

/*=============================================================================================================================
    Empty Cart
=============================================================================================================================*/

    empty_cart: function(cart_id, callback){
        /* Delete Cart */
        con.query("DELETE FROM tbl_cart WHERE id = '"+cart_id+"' ", function (err, result, fields) {

            /* Delete Cart Details */
            con.query("DELETE FROM tbl_cart_details WHERE cart_id = '"+cart_id+"' ", function (err, result, fields) {
                callback(1);
            })
        })
    },


/*=============================================================================================================================
    My Order
=============================================================================================================================*/

    my_order_list: function(req,callback){

        var where = (req.type == 'past')?`AND o.status IN ('Completed','Cancelled')`:`AND o.status IN ('Request','Preparing','Ready')`;

        con.query(`SELECT o.*,o.id as order_id,c.name,CONCAT('`+process.env.image_base_url+process.env.USER_IMAGE+`','',c.image) as image
            FROM tbl_order o
            JOIN tbl_user c ON o.chef_id = c.id
            WHERE o.user_id = "`+req.login_user_id+`" AND o.is_active = '1' `+where+` 
            ORDER BY o.id DESC
            LIMIT `+req.limit+`, `+req.per_page+`  `, function (err, result, fields) {
            //console.log(query.sql);
            if (!err) {
                
                if (result[0] !== undefined){

                    callback(result, t('text_my_order_list_succ'),1);
                }
                else{
                    callback(null,t('text_my_order_list_fail'),2);    
                }
            }
            else {
                callback(null,t('text_my_order_list_fail'),2);
            }
        });
    },


/*=============================================================================================================================
    Review Alert
=============================================================================================================================*/

    review_alert: function(req, callback){
        
        var response = [];

        con.query(`SELECT o.id as order_id,user_id,chef_id,c.name,TIME_FORMAT(TIMEDIFF(NOW(),o.arrival_time), '%H:00') AS TimeDiff
                FROM tbl_order o
                JOIN tbl_user c ON o.chef_id = c.id
                WHERE o.is_active = "1" AND o.user_id = "`+req.login_user_id+`" AND o.status = "Completed" AND o.is_review = "0"
                HAVING TimeDiff >= "01:00"
                ORDER BY o.insertdate DESC `, function (err, result, fields) {
            //console.log(query.sql);
            if (!err) {
                
                if (result[0] !== undefined){

                    callback(result, t('text_review_list_succ'), 1);
                }
                else{
                    callback(null, t('text_review_list_fail'), 0); 
                }
            }
            else {
                callback(null, t('text_review_list_fail'), 0);
            }
        });
    },


/*=============================================================================================================================
    Give Review
=============================================================================================================================*/

    give_review: function(req,callback){
        
        /* If Rate and Review Provided */
        if( (req.rating != 0 && req.review != undefined && req.review != '') || 
            (req.rating == 0 && req.review != undefined && req.review != '') || 
            (req.rating != 0 && (req.review == undefined || req.review == '') ) 
        ){
            con.query("SELECT rr.* FROM tbl_chef_rating_review rr WHERE rr.order_id = '"+req.order_id+"' AND rr.chef_id = '"+req.chef_id+"' ", function (err, result, fields) {
                //console.log(result);
                if (!err) 
                {
                    /* Already review the order */
                    if (result[0] != undefined)
                    {
                        callback(null,t('text_give_review_fail'), 0);
                    }
                    else{
                        
                        var params  = {
                            user_id: req.login_user_id,
                            order_id: req.order_id,
                            chef_id : req.chef_id,
                            rating: req.rating,
                            review: (req.review != undefined && req.review != '')?req.review:'',
                        };

                        con.query("INSERT INTO tbl_chef_rating_review SET ? ", params, function (err, avg_result, fields) {

                            con.queryAsync("UPDATE tbl_order SET ? WHERE id = '"+req.order_id+"' ", {is_review: '1'} );

                            callback(true,t('text_give_review_succ'), 1);                            
                        });

                    } // end else
                }// if end
                else {
                    callback(null,t('text_give_review_fail1'), 0)
                } // end else
            });
        } // if end
        else{
            con.query("UPDATE tbl_order SET ? WHERE id = '"+req.order_id+"' ", {is_review: '2'});

            callback(true,t('text_give_review_skip'), 1)
        }
            
    },


/*=============================================================================================================================
        Cancel Order
=============================================================================================================================*/

    cancel_order: function(req,callback){
        
        var query = con.query(`SELECT o.*,u.name FROM tbl_order o JOIN tbl_user u ON o.user_id = u.id
            WHERE o.id = '`+req.order_id+`' AND o.user_id = '`+req.login_user_id+`' `, function (err, result, fields) {
            //console.log(result);
            if (!err && result[0] != undefined) 
            {
                /* Check Order is not in Cancelled State */
                if(result[0].status != 'Cancelled' && result[0].status != 'Completed'){

                    var deduct_per = 0;
                    if(result[0].status == 'Request'){
                        deduct_per = 25;
                    }
                    else if(result[0].status == 'Preparing'){
                        deduct_per = 50;
                    }
                    else if(result[0].status == 'Ready'){
                        deduct_per = 75;
                    }

                    var amount = ((parseFloat(result[0].chef_earning) * deduct_per)/100);
                    var amount_deduct = parseFloat(amount) + parseFloat(result[0].app_earning);

                    var paymentObject = {
                            amount: Math.round(amount_deduct * 100),
                        }

                    stripe.captureStripeChargePartial(result[0].transaction_id, paymentObject,function(refund, refundmsg,refundcode){

                        if (refund != null) {

                            var params = {
                                status: 'Cancelled',
                                cancelled_by: 'Customer',
                                cancel_reason: req.cancel_reason,
                                payment_status: 'Refund',
                                refund_amount: (parseFloat(result[0].grand_total) - parseFloat(amount))
                            }

                            con.query('UPDATE tbl_order SET ? WHERE id = "'+req.order_id+'" ', params, function (err, result1, fields) {

                                /* Send Push Notification */
                                var push_params = {
                                    message: t('text_notify_chef_order_status',{ customer: result[0].name}),
                                    user_id : result[0].chef_id,
                                    tag: 'order_status',
                                    params: {
                                        user_id: result[0].chef_id,
                                        action_id: result[0].id,
                                        notification_lang_tag: 'text_notify_order_status',
                                        type: 'Cancelled'
                                    }
                                }
                                
                                common.prepare_notification(result[0].chef_id,'CHEF',push_params);

                                callback(true,t('text_chef_approve_reject_succ',{ field: params.status}), 1);
                            })
                        }
                        else{
                            callback(null,refundmsg, 0)
                        }
                    })

                } // end if
                else{
                    callback(null,t('text_chef_approve_reject_order_already_accept',{ field: result[0].status}), 0)
                }
            }
            else {
                callback(null,t('text_rest_something_went_wrong'), 0)
            }
        });
    },


/*=============================================================================================================================
        User Account Links
=============================================================================================================================*/

    api_user_list: function(callback){
        var response = {};
        con.query("SELECT u.*,IFNULL(ud.token,'') as token,IFNULL(ud.device_type,'') as device_type,IFNULL(ud.device_token,'') as device_token FROM tbl_user u LEFT JOIN tbl_user_device ud ON u.id = ud.user_id GROUP BY u.id ", function (err, result, fields) {
            // console.log(err);
            // console.log(result)
            if (!err) {
                if (result[0] != undefined) 
                {
                    callback(result);
                }
                else{
                    callback(null, err.sqlMessage);
                }
            }
            else {
                //console.log(err.sqlMessage);
                callback(null, err.sqlMessage);
            }
        });
    },


}

module.exports = Customer;
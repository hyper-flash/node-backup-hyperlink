var express = require('express');
var router = express.Router();
/*Load routing files*/

var customer = require('./Customer/route');
var chef = require('./Chef/route');
var service = require('./Service/route');

/* Token Check */
var common = require('../../config/common');

/*Use common files*/
router.use('/', common.validate_token);

/*Use routing files*/

router.use('/Customer/', customer);
router.use('/Chef/', chef);
router.use('/Service/', service);

module.exports = router;
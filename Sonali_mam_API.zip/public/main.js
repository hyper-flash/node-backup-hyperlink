$(function() {
	
	// Initialize variables
	var $window = $(window);

	var game_data = $("#game_id");
	var start_game = $("#start_game")

	var socket = io.connect('http://192.168.1.173:8086/Game?token=DXrsvUrRZDWCZACB6kCz598ECUtRVwPGcPBSn8fUw2MmVwwx7gMpvjwi3Gw73mnR')


	//Listen on new_message
	socket.on("new game", (data) => {
		
		$('#question_data').append("<p class='count'>"  + data.group_lenght + "</p>")
	})

	socket.on("currentGame", (data) => {
		
		$('#question_data').append("<p class='count'>"  + data + "</p>")
	})

	socket.on("broadcast", (data) => {
		
		$('#question_data').append("<p class='count'>"  + data.data + "</p>")
	})

	start_game.click(function(){
		
		var game_id  = game_data.val()
		// game_data.val('')
		socket.emit('currentGame', game_id)
	})

	$('#broadcast').click(function(){
		
		socket.emit('broadcast', '')
	})

	socket.on('typing', function (data) {
		
	  addChatTyping(data);
	});

	socket.on('stop typing', function (data) {
		
	  addChatTyping(data);
	});

	function addChatTyping (data) {

		var typingClass = data.typing ? 'typing ... ' : '';
	  $('.type_messages').html("<li>"  + typingClass + "</li>")
	}

	$("#message").keypress(function(event){
		
		socket.emit('typing');
	})

	$("#message").focusout(function(event){
		
		socket.emit('stop typing');
	})

	
  });
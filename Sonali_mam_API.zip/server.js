var express    = require('express');        // call express
var path = require('path');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
const globals = require('dotenv');
globals.config();
const cors = require('cors');
var cron = require('node-cron');
const common = require('./config/common');
const con = require('./config/database');

require('events').EventEmitter.defaultMaxListeners = 0

var app = express();                 // define our app using express
app.use(cors());

/* Language File Load */
// =============================================================================
const localizify = require('localizify');
const en = require('./languages/en.json');
const fr = require('./languages/fr.json');


// =============================================================================
// configure app to use bodyParser()
// this will let us get the data from a POST
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.text());

app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));


// ROUTES FOR OUR API
// =============================================================================

var route_v1 = require('./modules/v1/route');
var api_doc = require('./modules/v1/Api_document/route');


// set localization
// =============================================================================
localizify.add('en', en).add('fr', fr);
app.use((request, response, next) => {

    const lang = localizify.detectLocale(request.headers['accept-language']) || "en";
    localizify.setLocale(lang);
    request.login_language = lang;
    next();
});

app.use('/api/v1', route_v1);
app.use('/v1/', api_doc);

/*  CRON or JOB SCHEDULER (RUN IN EVERY GIVEN TIME)
 ┌────────────── second (optional)  0-59
 │ ┌──────────── minute             0-59
 │ │ ┌────────── hour               0-23
 │ │ │ ┌──────── day of month       1-31
 │ │ │ │ ┌────── month              1-12 or name
 │ │ │ │ │ ┌──── day of week        0-7 or name (0 or 7 are sunday)
 * * * * * *    */
cron.schedule('0 * * * * *', function(){
    //console.log(Date());

    const customer_model = require('./modules/v1/Customer/customer_model');

    customer_model.captureStripeCharge();
});

// catch 404 and forward to error handler
app.use(function(req, res, next) 
{
    res.render(path.join(__dirname+'/view/index.ejs'), { globals: globals })
    var err = new Error('Not Found');
    err.status = 404;
    next();
});

// START THE SERVER
// =============================================================================

try {
    //set the template engine ejs
    app.set('view engine', 'ejs')

    //middlewares
    app.use(express.static('public'))
  
    var port = process.env.PORT || 8080;        // set our port
	app.listen(port);

} catch (err) {
    console.log("Failed to start server"); 
}
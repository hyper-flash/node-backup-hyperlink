const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
var fs          = require('fs');

// get an instance of the express Router
var Payment = {
    create_customer(req, cb) {
        stripe.customers.create({
            description: 'Customer '+req.email,
            email: req.email
        }, function (err, customer) {
            if (!err) {
                cb(customer, 'success', '1')
            } else {
                cb(undefined, err.raw.message, '0')
            }
        });
    },
    create_card_token(req, cb) {
        stripe.tokens.create({
            card: {
                name: req.name,
                number: req.number,// '4242424242424242',
                exp_month: req.exp_month,// 12,
                exp_year: req.exp_year,// 2020,
                cvc: req.cvc,//'123'
            }
        }, function (err, token) {
            if (!err) {
                cb(token, 'success', '1');
            } else {
                cb(undefined, err.raw.message, '0');
            }
        });
    },
    create_source(req, cb) {
        stripe.customers.createSource(
            req.customer_id,//'cus_Fxw2chQnvbEaaf',
            {
                source: req.token,//'tok_1FRzy5GvmRRHmnzG4bnz9dtL',
            }, function (err, source) {
                if (!err) {
                    cb(source, 'success', '1');
                } else {
                    cb(undefined, err.raw.message, '0');
                }
            });
    },
    update_source(req, cb) {
        stripe.customers.update(
            req.customer_id,
            {
                default_source: req.card_id,
            },
            function (err, confirmation) {
                if (!err) {
                    cb(confirmation, 'success', '1');
                } else {
                  console.log(err);
                    cb(undefined, err.raw.message, '0');
                }
            }
        );
    },
    delete_source(req, cb) {
        stripe.customers.deleteSource(
            req.customer_id,
            req.card_id,
            function (err, confirmation) {
                if (!err) {
                    cb(confirmation, 'success', '1');
                } else {
                    cb(undefined, err.raw.message, '0');
                }
            }
        );
    },

    /**
     * Function to upload users identity to stripe
     * 23-01-2020
     * @param {Request Data} request 
     * @param {Function} callback 
     */
    uploadIdentityStripe(request,callback) {
        
        var fp = fs.readFileSync("./public/" + process.env.BANK_IMAGE + request.bank_document);
        var file = {};
        stripe.files.create({
            purpose: 'identity_document',
            file: {
                data: fp,
                name: request.bank_document,
                type: 'application/octet-stream'
            }
        }, function (errors, fileUpload) {
            if (errors) {
                callback(undefined,errors.message,'0');
            } else {
                file = fileUpload;
                callback(file, "File upload success", "1");
            }
        });
    },

    /**
     * Function to create account on stripe
     * 02-05-2020
     * @param {Account Object} accountObject 
     * @param {Function} callback 
     */
    createAccount(accountObject,callback) {
        stripe.accounts.create(accountObject, function(errors, account) {
            if (!errors && account != undefined) {
                callback(account, 'success', '1');
            } else {
                callback(undefined,errors.message,'0');
            }
        });
    },

    /**
     * Function to update account on stripe
     * 02-05-2020
     * @param {Account Object} accountObject 
     * @param {Function} callback 
     */
    updateAccount(merchant_account_id, accountObject,callback) {
        stripe.accounts.update(merchant_account_id, accountObject, function(errors, account) {
            if (!errors && account != undefined) {
                callback(account, 'success', '1');
            } else {
                callback(undefined,errors.message,'0');
            }
        });
    },

    /**
     * Function to update account on stripe
     * 02-05-2020
     * @param {Account Object} accountObject 
     * @param {Function} callback 
     */
    delAccount(accountId,callback) {
        stripe.accounts.del(accountId, function(errors, account) {
            if (!errors && account != undefined) {
                callback(account, 'success', '1');
            } else {
                callback(undefined,errors.message,'0');
            }
        });
    },

    /**
     * Function to create stripe charge [Note : if payment object contains capture parameter set to false than need to capture this charge]
     * @description This is not direct charge so transaction fees will be deducted from platform account [client account]
     * @param {Payment Object} paymentobject 
     * @param {Function} callback 
     */
    createStripeCharge(paymentobject,callback) {
        stripe.charges.create(paymentobject,function(err, charge) {
            if (!err && charge != undefined) {
                callback(charge,"Charge Created",'1');
            } else {
                callback(null,err.message,'0');
            }      
        });
    },

    /**
     * Function to capture the charge which is created with capture false otherwise no need for capture
     * @param {Charge ID} charge_id 
     * @param {Function} callback 
     */
    captureStripeCharge(charge_id,callback) {
        stripe.charges.capture(charge_id,function(err, charge) {
            if (!err && charge != undefined) {
                callback(charge,"Charge Captured", '1');
            } else {
                callback(null,err.message,'0');
            }
        });
    },

    /**
     * Function to capture the charge which is created with capture false otherwise no need for capture
     * @param {Charge ID} charge_id 
     * @param {Function} callback 
     */
    captureStripeChargePartial(charge_id, charge,callback) {
        stripe.charges.capture(charge_id, charge,function(err, charge) {
            if (!err && charge != undefined) {
                callback(charge,"Charge Captured", '1');
            } else {
                callback(null,err.message,'0');
            }
        });
    },

    /**
     * Function to refund the charge which is put on hold by stripe.charge method
     * @param {Charge ID} charge_id 
     * @param {Function} callback 
     */
    createChargeRefund(charge,callback) {
        stripe.refunds.create(charge,function(error, refund) {
            if (!error && refund != undefined) {
                callback(refund,"Charge Refunded",'1');
            } else {
                callback(null,error.message,'0');
            }
        });
    },
}
module.exports = Payment;

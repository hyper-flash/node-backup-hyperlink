const con = require('./database');
const _randomhash = require('crypto-toolkit').RandomHash('base64-urlsafe');
const cryptoLib = require('cryptlib');
const shaKey = cryptoLib.getHashSha256(process.env.ENC_KEY, 32); // This line is not needed on Android or iOS. Its already built into CryptLib.m and CryptLib.java
const nodemailer = require('nodemailer');

// Language file load
const { t } = require('localizify');

// get an instance of the express Router
var Validate = {

    validate_token: function(req,res,callback){

        // console.log(req);

        var path_data = req.path.split("/");

        
        var method = new Array ("signup","login","country_list","forgot_password","data","states_list","unique_details_check","send_otp", "verify_otp","image_upload");

        /*Decryption api-key*/
        try {
            var api_key = cryptoLib.decrypt(req.headers['api-key'], shaKey, process.env.ENC_IV);
            
            if (api_key == process.env.API_KEY) {
                
                if (method.indexOf(path_data[path_data.length-1]) === -1) {//if (method.indexOf(path_data[4]) === -1) {

                    if (req.headers['token']) {
                        
                        var query = con.query("SELECT ud.* FROM tbl_user_device ud WHERE token = '" + cryptoLib.decrypt(req.headers['token'], shaKey, process.env.ENC_IV) + "' ", function (err, result) {

                            if (result[0] == undefined) {
                                response_data = {
                                    code: '-1',
                                    message: t('text_rest_invalid_token'),
                                    data: ''
                                };

                                Validate.encryption(response_data,function(responseData){
                                    res.status(401);
                                    res.json(responseData);
                                })
                            }
                            else{
                                req.login_user_id = result[0].user_id;
                                callback();
                            }
                        })
                    }
                    else{
                        response_data = {
                            code: '-1',
                            message: t('text_rest_invalid_token'),
                            data: ''
                        };

                        Validate.encryption(response_data,function(responseData){
                            res.status(401);
                            res.json(responseData);
                        })
                        
                    }
                }
                else{
                    callback();
                }
            }//end if
            else{
                response_data = {
                    code: '-1',
                    message: t('text_rest_invalid_api_key'),
                    data: ''
                };

                Validate.encryption(response_data,function(responseData){
                    res.status(401);
                    res.json(responseData);
                })
            }
        } catch (err) {
            response_data = {
                code: '0',
                message: t('text_rest_invalid_credentials'),
            };
            Validate.encryption(response_data, function(response){
                res.status(200);
                res.json(response);
            });
        }
        
    },

/*=============================================================================================================================
        Request decryption
=============================================================================================================================*/

    decryption: function(req,callback){
        if(req.body != undefined && Object.keys(req.body).length !== 0){
            
            try {
                var request = JSON.parse(cryptoLib.decrypt(req.body, shaKey, process.env.ENC_IV));
            } catch (e) {
                var request = cryptoLib.decrypt(req.body, shaKey, process.env.ENC_IV);
            }

            if(req.login_user_id != undefined){
                request.login_user_id = req.login_user_id
                request.login_language = req.login_language
                callback(request);
            }
            else{
                request.login_language = req.login_language
                callback(request);
            }
        }
        else{
            if(req.login_user_id != undefined){
                var request = {};
                request.login_user_id = req.login_user_id
                request.login_language = req.login_language
                callback(request);
            }
            else{
                var request = {};
                request.login_language = req.login_language
                callback(request);
            }
        }
            
    },

/*=============================================================================================================================
        Request encryption
=============================================================================================================================*/

    encryption: function(req,callback){
        //console.log(req)
        
        var response = cryptoLib.encrypt(JSON.stringify(req), shaKey, process.env.ENC_IV);
        callback(response);
            
    },

    
/*=============================================================================================================================
       Send Push
=============================================================================================================================*/

    prepare_notification: function (user_id, topic, push_params, registrationIds) {

        if (registrationIds == undefined) {
            var query = con.query("SELECT device_token,device_type FROM tbl_user_device d WHERE d.user_id = '" + user_id + "' ", function (err, result, fields) {

                if (!err) {
                    if (result[0] != undefined) {

                        /* Add Notification in list */

                        Validate.add_notification_list(push_params.params);

                        const registrationIds = [];
                        registrationIds.push(result[0].device_token);
                        Validate.send_push(registrationIds, result[0].device_type, topic, push_params);
                        
                    }
                }
            });
        } else {
            Validate.send_push(registrationIds, 'A', topic, push_params);
        }

    },


    send_push: function (registrationIds, device_type, topic, push_params) {

        
        const push_data = {
            topic: process.env[`${topic}`+'_BUNDLE_ID'],
            custom: {
                title: process.env.APP_NAME,
                body: push_params.message,
                tag: push_params.tag,
                data: push_params
            },
            alert : {
                title: process.env.APP_NAME,
                body: push_params.message,
                tag: push_params.tag
            }
            /*expiry: Math.floor(Date.now() / 1000) + 28 * 86400,
            retries: -1,*/
        };

        if (device_type === 'I') {
            push_data.sound = 'default';
        }


        const settings = {
            gcm: {
                id: process.env.GCM_PUSH_KEY,
            },
            apn: {
                token: {
                    key: process.env.APN_PUSH_KEY, // optionally: fs.readFileSync('./certs/key.p8')
                    keyId: process.env.KEY_ID,
                    teamId: process.env.TEAM_ID,
                },
                production: false
            },
            isAlwaysUseFCM: false
        };
        const PushNotifications = require('node-pushnotifications');
        const push = new PushNotifications(settings);

        // console.log(push_data);

        push.send(registrationIds, push_data, (err, result) => {
            // console.log(result);
            /*if (err) {
                console.log('error');
                console.log(err);
            } else {
                console.log('succ');
                console.log(result);
                console.log(result[0].message);
            }*/
        });

    },


/*=============================================================================================================================
    Add Into Notification List
=============================================================================================================================*/

    add_notification_list: function(req){

        var params  = {
                user_id: req.user_id, 
                action_id: req.action_id,
                notification_lang_tag: req.notification_lang_tag,
                type: req.type,
            };
        var query = con.query('INSERT INTO tbl_notification_details SET ?', params, function (err, result, fields) {
            
        });
         
    },


/*=============================================================================================================================
        Send email
=============================================================================================================================*/

    send_email: function(subject,to_email,message,callback){

        var transporter = nodemailer.createTransport({
            host: 'smtpout.secureserver.net',
            port: 465,
            secure: true, // true for 465, false for other ports
            auth: {
                user: process.env.EMAIL_ID, // generated ethereal user
                pass: process.env.EMAIL_PASS // generated ethereal password
            }
        });
    
        // setup email data with unicode symbols
        var mailOptions = {
            from: process.env.APP_NAME+' App <'+process.env.FROM_EMAIL+'>', // sender address
            to: to_email, // list of receivers
            subject: subject, // Subject line
            html: message
        };
    
        // send mail with defined transport object
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.log("ERROR FOUND :::::::: ++++++++++++++ ")
                console.log(error);
                //callback(true);
            }
            //console.log('Message sent: %s', info.messageId);
            // Preview only available when sending through an Ethereal account
            //console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));

            callback(true);

        });
    },


    getSettingsValue: function (attribute_name, callback) {
        var query = con.query("SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = '" + attribute_name + "' ", function (err, result, fields) {

            if (!err && result[0] != undefined) {
                callback(result[0]['attribute_value']);
            } else {
                callback(false);
            }
        })
    },


    random_name: function(length){
       var result           = '';
       var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
       var charactersLength = characters.length;
       for ( var i = 0; i < length; i++ ) {
          result += characters.charAt(Math.floor(Math.random() * charactersLength));
       }
       return result;
    },


/*=============================================================================================================================
        Send OTP
=============================================================================================================================*/

    send_otp_number: function(req, callback){

        const client = require('twilio')(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

        client.messages
          .create({
             body: 'OTP for linking your '+process.env.APP_NAME+' account is '+req.OTP,
             from: process.env.TWILIO_FROM,
             to: req.code+req.mobile_number
           }, function(err, msg){

            // console.log(err);
            if(err){
                if(err.code == 21614){
                    callback(t('text_customer_otp_invalid_number'), 0);
                }
                else{
                    // callback(t('text_customer_otp_send_fail'), 0);
                    callback(t('text_customer_otp_send_succ'),1);
                }
            }
            else{
                callback(t('text_customer_otp_send_succ'),1);
            }
            /*console.log(err);
            console.log(msg);*/
            
           })
       
    },



}

module.exports = Validate;

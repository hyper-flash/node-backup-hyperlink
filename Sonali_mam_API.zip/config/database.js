const mysql = require('mysql');
 
const pool = require('mysql').createPool({
    connectionLimit : 10,
    connectTimeout  : 60 * 60 * 1000,
    acquireTimeout  : 60 * 60 * 1000,
    timeout         : 60 * 60 * 1000,
    host            : process.env.DB_HOST,
    user            : process.env.DB_USERNAME,
    password        : process.env.DB_PASSWORD,
    database        : process.env.DB_DATABASE,
    dateStrings     : 'date',
    charset         : 'utf8mb4'
});                           
 
var DB = (function () {

    function _query(query, params, callback) {
        // console.log(query);


        pool.query(query, params, function (err, rows, fields) {
            if (!err) {
                callback(null, rows, fields);
            }
            else {
                console.log('connection release 1: ',err);
                callback(err, null);
            }

        });
    };

    function _queryAsync(query, params) {
        
        pool.query(query, params, function (err, rows, fields) {

        });
        
    };

    return {
        query: _query,
        queryAsync: _queryAsync
    };
})();

module.exports = DB;